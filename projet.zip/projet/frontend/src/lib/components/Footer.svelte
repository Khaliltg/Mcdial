<style>
  footer {
    background-color: #f8f9fa; /* Original background color */
    padding: 20px;
    width: 100%;
    text-align: center;
    margin-top: 20px;
    border-top: 1px solid #ddd;
    position: static; /* Ensure footer stays at the bottom */
    color: #333; /* Text color for readability */
  }

  .social-links a {
    color: #6c757d; /* Original link color */
    margin: 0 10px;
    text-decoration: none;
    font-size: 20px;
  }

  .social-links a:hover {
    color: #007bff; /* Original hover color */
  }

  /* Additional styles for dark background if needed */
  footer.dark {
    background: #333;
    color: white;
  }
</style>

<footer>
  <div class="container">
    <div class="d-flex justify-content-between align-items-center">
      <div class="d-flex align-items-center">
        <i class="bi bi-graph-up-arrow me-2 text-primary"></i>
        <span class="text-muted">Mc_solutions</span>
      </div>
      <div class="text-muted small">
        &copy; 2025 Your Company. Tous droits réservés.
      </div>
      <div class="social-links">
        <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
          <i class="bi bi-twitter"></i>
        </a>
        <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer">
          <i class="bi bi-linkedin"></i>
        </a>
        <a href="https://github.com" target="_blank" rel="noopener noreferrer">
          <i class="bi bi-github"></i>
        </a>
      </div>
    </div>
  </div>
</footer>