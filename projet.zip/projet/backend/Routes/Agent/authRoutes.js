const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const db = require('../../config/bd');
const { authenticateToken } = require('../../middleware/auth');
const asteriskService = require('../../services/asteriskService');

// Route pour l'authentification téléphonique (étape 1)
router.post('/phone-login', async (req, res) => {
    console.log('Requête reçue sur /api/agent/auth/phone-login');
    console.log('Corps de la requête:', req.body);
    
    const { phoneLogin, phonePassword } = req.body;
    
    if (!phoneLogin || !phonePassword) {
        console.log('Erreur: Identifiant et mot de passe téléphonique requis');
        return res.status(400).json({ message: 'Identifiant et mot de passe téléphonique requis' });
    }
    
    try {
        // Vérifier les identifiants téléphoniques dans la table phones
        // Utilisation de la même structure que Vicidial
        console.log('Vérification des identifiants téléphoniques...');
        const [rows] = await db.query('SELECT * FROM phones WHERE login = ? AND active = "Y"', [phoneLogin]);
        
        if (rows.length === 0) {
            console.log('Identifiants téléphoniques invalides');
            return res.status(401).json({ message: 'Identifiants téléphoniques invalides' });
        }
        
        const phone = rows[0];
        
        // Comparer le mot de passe (en texte brut comme dans Vicidial)
        console.log('Vérification du mot de passe...');
        const valid = phonePassword === phone.pass;
        
        if (!valid) {
            console.log('Mot de passe téléphonique invalide');
            return res.status(401).json({ message: 'Identifiants téléphoniques invalides' });
        }
        
        console.log('Récupération des informations du téléphone...');
        const extension = phone.extension;
        const dialplan_number = phone.dialplan_number;
        const voicemail_id = phone.voicemail_id;
        const phone_ip = phone.phone_ip;
        
        // Créer un token de session temporaire pour l'étape téléphonique
        console.log('Création du token de session téléphonique...');
        const phoneSessionToken = jwt.sign({
            phone_id: phone.id,
            phone_login: phone.login,
            extension: extension,
            dialplan_number: dialplan_number,
            voicemail_id: voicemail_id,
            phone_ip: phone_ip,
            step: 'phone'
        }, process.env.JWT_SECRET, { expiresIn: '15m' }); // Courte durée pour la sécurité
        
        // Retourner le token de session téléphonique
        console.log('Authentification téléphonique réussie');
        res.json({
            success: true,
            phoneSessionToken,
            extension,
            dialplan_number,
            voicemail_id,
            phone_ip
        });
    } catch (err) {
        console.error('Erreur dans phone-login:', err);
        res.status(500).json({ message: 'Erreur serveur' });
    }
});

// Route pour l'authentification utilisateur (étape 2)
router.post('/user-login', async (req, res) => {
    console.log('Requête reçue sur /api/agent/auth/user-login');
    console.log('Corps de la requête:', req.body);
    
    const { userLogin, userPassword } = req.body;
    
    if (!userLogin || !userPassword) {
        console.log('Erreur: Identifiant et mot de passe utilisateur requis');
        return res.status(400).json({ message: 'Identifiant et mot de passe utilisateur requis' });
    }
    
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        console.log('Erreur: Token de session téléphonique requis');
        return res.status(401).json({ message: 'Token de session téléphonique requis' });
    }
    
    const phoneSessionToken = authHeader.split(' ')[1];
    
    try {
        // Vérifier et décoder le token de session téléphonique
        console.log('Vérification du token de session téléphonique...');
        const decoded = jwt.verify(phoneSessionToken, process.env.JWT_SECRET);
        
        if (decoded.step !== 'phone') {
            console.log('Erreur: Étape du token invalide');
            return res.status(401).json({ message: 'Token de session téléphonique invalide' });
        }
        
        console.log('Vérification des identifiants utilisateur...');
        const [rows] = await db.query('SELECT * FROM vicidial_users WHERE user = ? AND user_level > 0', [userLogin]);
        
        if (rows.length === 0) {
            console.log('Identifiants utilisateur invalides');
            return res.status(401).json({ message: 'Identifiants utilisateur invalides' });
        }
        
        const user = rows[0];
        
        // Comparer le mot de passe (en texte brut comme dans Vicidial)
        console.log('Vérification du mot de passe...');
        const valid = userPassword === user.pass;
        
        if (!valid) {
            console.log('Mot de passe utilisateur invalide');
            return res.status(401).json({ message: 'Identifiants utilisateur invalides' });
        }
        
        // Vérifier si l'utilisateur est un agent (user_level <= 4)
        // Dans Vicidial, les agents ont généralement un user_level de 1
        if (user.user_level > 4) { // Agents ont un user_level <= 4
            console.log('Erreur: Utilisateur non autorisé');
            return res.status(403).json({ message: 'Accès non autorisé pour ce type d\'utilisateur' });
        }
        
        console.log('Récupération des campagnes...');
        const [campaigns] = await db.query(`
            SELECT campaign_id as id, campaign_name as name, active, dial_method,
                   dial_timeout, lead_filter_id, hopper_level, auto_dial_level
            FROM vicidial_campaigns
            WHERE active='Y'
        `);
        
        // Créer un token de session utilisateur avec toutes les informations nécessaires
        console.log('Création du token de session utilisateur...');
        const userSessionToken = jwt.sign({
            phone_id: decoded.phone_id,
            phone_login: decoded.phone_login,
            extension: decoded.extension,
            dialplan_number: decoded.dialplan_number,
            voicemail_id: decoded.voicemail_id,
            phone_ip: decoded.phone_ip,
            user_id: user.user_id,
            user: user.user,
            user_level: user.user_level,
            full_name: user.full_name,
            step: 'user'
        }, process.env.JWT_SECRET, { expiresIn: '15m' }); // Courte durée pour la sécurité
        
        // Retourner le token de session utilisateur et les campagnes
        console.log('Authentification utilisateur réussie');
        res.json({
            success: true,
            userSessionToken,
            campaigns
        });
    } catch (err) {
        if (err.name === 'JsonWebTokenError' || err.name === 'TokenExpiredError') {
            console.log('Erreur: Token de session téléphonique expiré ou invalide');
            return res.status(401).json({ message: 'Token de session téléphonique expiré ou invalide' });
        }
        
        console.error('Erreur dans user-login:', err);
        res.status(500).json({ message: 'Erreur serveur' });
    }
});

// Route pour la sélection de campagne (étape 3)
router.post('/select-campaign', async (req, res) => {
    console.log('Requête reçue sur /api/agent/auth/select-campaign');
    console.log('Corps de la requête:', req.body);
    console.log('En-têtes:', req.headers);
    
    const { campaignId } = req.body;
    
    if (!campaignId) {
        console.log('Erreur: ID de campagne requis');
        return res.status(400).json({ message: 'ID de campagne requis' });
    }
    
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        console.log('Erreur: Token de session utilisateur requis');
        return res.status(401).json({ message: 'Token de session utilisateur requis' });
    }
    
    const userSessionToken = authHeader.split(' ')[1];
    
    try {
        // Vérifier et décoder le token de session utilisateur
        console.log('Vérification du token de session utilisateur...');
        const decoded = jwt.verify(userSessionToken, process.env.JWT_SECRET);
        
        if (decoded.step !== 'user') {
            console.log('Erreur: Étape du token invalide');
            return res.status(401).json({ message: 'Token de session utilisateur invalide' });
        }
        
        // Vérifier si la campagne existe et est active
        console.log('Vérification de la campagne...');
        const [campaign] = await db.query(`
            SELECT campaign_id, campaign_name, active, dial_method,
                   dial_timeout, lead_filter_id, hopper_level, auto_dial_level
            FROM vicidial_campaigns
            WHERE campaign_id = ? AND active = 'Y'
        `, [campaignId]);
        
        if (campaign.length === 0) {
            console.log('Campagne non trouvée ou inactive');
            return res.status(404).json({ message: 'Campagne non trouvée ou inactive' });
        }
        
        // Mettre à jour la campagne de l'utilisateur dans vicidial_users
        console.log('Mise à jour de la campagne de l\'utilisateur...');
        await db.query(`
            UPDATE vicidial_users 
            SET campaign_id = ?, campaign_name = ?
            WHERE user = ?
        `, [campaignId, campaign[0].campaign_name, decoded.user]);
        
        // Créer un token final avec toutes les informations
        console.log('Création du token final...');
        const finalToken = jwt.sign({
            ...decoded,
            campaign_id: campaignId,
            campaign_name: campaign[0].campaign_name,
            dial_method: campaign[0].dial_method,
            dial_timeout: campaign[0].dial_timeout,
            lead_filter_id: campaign[0].lead_filter_id,
            hopper_level: campaign[0].hopper_level,
            auto_dial_level: campaign[0].auto_dial_level,
            step: 'final'
        }, process.env.JWT_SECRET, { expiresIn: '15m' });
        
        // Retourner le token final et les informations de campagne
        console.log('Sélection de campagne réussie');
        res.json({
            success: true,
            token: finalToken,
            campaign: {
                id: campaignId,
                name: campaign[0].campaign_name,
                dialMethod: campaign[0].dial_method,
                dialTimeout: campaign[0].dial_timeout,
                leadFilterId: campaign[0].lead_filter_id,
                hopperLevel: campaign[0].hopper_level,
                autoDialLevel: campaign[0].auto_dial_level
            }
        });
    } catch (err) {
        if (err.name === 'JsonWebTokenError' || err.name === 'TokenExpiredError') {
            console.log('Erreur: Token de session utilisateur expiré ou invalide');
            return res.status(401).json({ message: 'Token de session utilisateur expiré ou invalide' });
        }
        
        console.error('Erreur dans select-campaign:', err);
        res.status(500).json({ message: 'Erreur serveur' });
    }
});

// Route pour vérifier l'authentification sans token
router.get('/check', async (req, res) => {
    console.log('Requête reçue sur /api/agent/auth/check');
    console.log('Cookies:', req.cookies);
    
    try {
        // Vérifier si l'utilisateur est authentifié via le token dans les cookies
        const token = req.cookies.jwt;
        console.log('Token trouvé:', !!token);
        
        if (!token) {
            console.log('Aucun token trouvé dans les cookies');
            return res.status(401).json({ authenticated: false, message: 'Aucun token trouvé' });
        }
        
        // Vérifier et décoder le token
        console.log('Vérification du token...');
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        console.log('Token décodé avec succès');
        const userId = decoded.user;
        
        // Vérifier si l'utilisateur existe dans la base de données
        console.log('Vérification de l\'utilisateur dans la base de données...');
        const [user] = await db.query('SELECT user_id, user, full_name FROM vicidial_users WHERE user = ?', [userId]);
        
        if (user.length === 0) {
            console.log('Utilisateur non trouvé dans la base de données');
            return res.status(401).json({ authenticated: false, message: 'Utilisateur non trouvé' });
        }
        
        console.log('Authentification réussie');
        res.json({ 
            authenticated: true, 
            user: {
                id: user[0].user_id,
                username: user[0].user,
                fullName: user[0].full_name
            }
        });
    } catch (err) {
        console.error('Erreur lors de la vérification de l\'authentification:', err);
        res.status(401).json({ authenticated: false, message: 'Token invalide' });
    }
});

// Route pour vérifier la validité du token
router.post('/verify-token', authenticateToken, (req, res) => {
    console.log('Requête reçue sur /api/agent/auth/verify-token');
    
    try {
        // Le middleware auth.js a déjà vérifié le token
        console.log('Token validé');
        res.json({ 
            valid: true,
            user: req.user
        });
    } catch (err) {
        console.error('Erreur dans verify-token:', err);
        res.status(500).json({ message: 'Erreur serveur' });
    }
});

// Route pour vérifier l'authentification avec token
router.get('/check', authenticateToken, async (req, res) => {
    console.log('Requête reçue sur /api/agent/auth/check avec token');
    
    try {
        // Si nous sommes ici, le middleware authenticateToken a validé le token
        const userId = req.user.user;
        
        // Vérifier si l'utilisateur existe dans la base de données
        console.log('Vérification de l\'utilisateur dans la base de données...');
        const [user] = await db.query('SELECT user_id, user, full_name FROM vicidial_users WHERE user = ?', [userId]);
        
        if (user.length === 0) {
            console.log('Utilisateur non trouvé dans la base de données');
            return res.status(401).json({ authenticated: false, message: 'Utilisateur non trouvé' });
        }
        
        console.log('Authentification réussie');
        res.json({ 
            authenticated: true, 
            user: {
                id: user[0].user_id,
                username: user[0].user,
                fullName: user[0].full_name
            }
        });
    } catch (err) {
        console.error('Erreur dans check avec token:', err);
        res.status(500).json({ message: 'Erreur serveur' });
    }
});

module.exports = { router, authenticateToken };
