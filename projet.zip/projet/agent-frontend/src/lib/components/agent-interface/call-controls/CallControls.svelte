<script lang="ts">
  import { createEventDispatcher } from 'svelte';
  
  const dispatch = createEventDispatcher();
  
  // Props
  export let callActive = false;
  export let callEnded = false;
  export let callId = '';
  export let leadId = null;
  export let phoneNumber = '';
  export let onMute = () => {};
  export let onHold = () => {};
  export let onRecord = () => {};
  export let onEndCall = () => {};
  export let onTransfer = () => {};
  export let onDTMF = () => {};
  export let onConference = () => {};
  
  // State
  let callMuted = false;
  let callOnHold = false;
  let recording = false;
  let transferType = 'blind';
  let transferDestination = '';
  let dtmfSequence = '';
  let transferModal = null;
  let dtmfModal = null;

  // Handlers
  function handleMute() {
    callMuted = !callMuted;
    onMute(callMuted);
  }
  
  function handleHold() {
    callOnHold = !callOnHold;
    onHold(callOnHold);
  }
  
  function handleRecord() {
    recording = !recording;
    onRecord(recording);
  }
  
  function handleEndCall() {
    callActive = false;
    callEnded = true;
    onEndCall();
  }
  
  function handleTransfer() {
    onTransfer({
      type: transferType,
      destination: transferDestination
    });
    transferModal.classList.add('hidden');
  }

  function handleTransferModal() {
    if (transferModal) {
      transferModal.classList.toggle('hidden');
    }
  }

  $: if ($event.type === 'openTransferModal') {
    handleTransferModal();
  }

  function handleDTMF() {
    onDTMF(dtmfSequence);
    dtmfModal.classList.add('hidden');
    dtmfSequence = '';
  }

  function handleDTMFMoadal() {
    if (dtmfModal) {
      dtmfModal.classList.toggle('hidden');
    }
  }

  $: if ($event.type === 'openDTMFMoadal') {
    handleDTMFMoadal();
  }

  function handleConference() {
    onConference();
  }
</script>

<div class="flex flex-col gap-4 p-4">
  <!-- Call Status -->
  <div class="flex items-center bg-green-100 text-green-800 px-3 py-1 rounded-full">
    <span class="w-2 h-2 bg-green-500 rounded-full animate-pulse mr-2"></span>
    <span class="font-medium">Appel en cours</span>
    <span class="ml-2 font-bold">00:00</span>
  </div>

  <!-- Lead Information -->
  <div class="grid grid-cols-2 gap-2">
    <div>
      <span class="text-sm text-gray-500">Client:</span>
      <span class="font-medium ml-1">Inconnu</span>
    </div>
    <div>
      <span class="text-sm text-gray-500">Numéro:</span>
      <span class="font-medium ml-1">{phoneNumber}</span>
    </div>
  </div>

  <!-- Call Control Buttons -->
  <div class="grid grid-cols-3 gap-4">
    <!-- Mute -->
    <button
      class="p-3 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
      on:click={handleMute}
    >
      {#if callMuted}
        <svg class="w-6 h-6 text-red-500" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd" />
        </svg>
      {:else}
        <svg class="w-6 h-6 text-gray-500" fill="currentColor" viewBox="0 0 20 20">
          <path d="M3 8a1 1 0 011-1h2a1 1 0 011 1v3a1 1 0 01-1 1H4a1 1 0 01-1-1V8zM5 0a5 5 0 00-5 5v8a5 5 0 005 5h8a5 5 0 005-5V5a5 5 0 00-5-5H5z" />
        </svg>
      {/if}
    </button>

    <!-- Hold -->
    <button
      class="p-3 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
      on:click={handleHold}
    >
      {#if callOnHold}
        <svg class="w-6 h-6 text-yellow-500" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd" />
        </svg>
      {:else}
        <svg class="w-6 h-6 text-gray-500" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM7 9a1 1 0 012 0v4a1 1 0 11-2 0V9zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V9a1 1 0 00-1-1z" clip-rule="evenodd" />
        </svg>
      {/if}
    </button>

    <!-- Record -->
    <button
      class="p-3 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
      on:click={handleRecord}
    >
      {#if recording}
        <svg class="w-6 h-6 text-red-500" fill="currentColor" viewBox="0 0 20 20">
          <path d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" />
        </svg>
      {:else}
        <svg class="w-6 h-6 text-gray-500" fill="currentColor" viewBox="0 0 20 20">
          <path d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" />
        </svg>
      {/if}
    </button>

    <!-- Transfer -->
    <button
      class="p-3 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
      on:click={() => dispatch('openTransferModal')}
    >
      <svg class="w-6 h-6 text-gray-500" fill="currentColor" viewBox="0 0 20 20">
        <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />
      </svg>
    </button>

    <!-- Conference -->
    <button
      class="p-3 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
      on:click={handleConference}
    >
      <svg class="w-6 h-6 text-gray-500" fill="currentColor" viewBox="0 0 20 20">
        <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z" />
      </svg>
    </button>

    <!-- Hangup -->
    <button
      class="p-3 rounded-full bg-red-500 hover:bg-red-600 text-white transition-colors"
      on:click={handleEndCall}
    >
      <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3" />
      </svg>
    </button>
  </div>

  <!-- Transfer Modal -->
  <div class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden" bind:this={transferModal}>
    <div class="relative w-full max-w-md p-4 mx-auto">
      <div class="bg-white rounded-lg shadow dark:bg-gray-700">
        <div class="p-6">
          <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Transfert d'appel</h3>
          
          <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700">Type de transfert</label>
            <select
              bind:value={transferType}
              class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="blind">Transfert aveugle</option>
              <option value="attended">Transfert assisté</option>
              <option value="local">Local</option>
              <option value="internal">Interne</option>
            </select>
          </div>

          <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700">Destination</label>
            <input
              type="text"
              bind:value={transferDestination}
              class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              placeholder="Numéro ou extension"
            />
          </div>

          <div class="flex justify-end space-x-2">
            <button
              class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
              on:click={() => transferModal.classList.add('hidden')}
            >
              Annuler
            </button>
            <button
              class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700"
              on:click={handleTransfer}
            >
              Transférer
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- DTMF Modal -->
  <div class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden" bind:this={dtmfModal}>
    <div class="relative w-full max-w-md p-4 mx-auto">
      <div class="bg-white rounded-lg shadow dark:bg-gray-700">
        <div class="p-6">
          <h3 class="text-lg font-semibold text-gray-900 dark:text-white mb-4">Envoyer DTMF</h3>
          
          <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700">Séquence DTMF</label>
            <input
              type="text"
              bind:value={dtmfSequence}
              class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              placeholder="Ex: 12345"
            />
          </div>

          <div class="flex justify-end space-x-2">
            <button
              class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
              on:click={() => dtmfModal.classList.add('hidden')}
            >
              Annuler
            </button>
            <button
              class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700"
              on:click={handleDTMF}
            >
              Envoyer
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<style>
  .animate-pulse {
    animation: pulse 1.5s cubic-bezier(0.4, 0, 0.6, 1) infinite;
  }

  @keyframes pulse {
    0%, 100% {
      opacity: 1;
    }
    50% {
      opacity: 0.5;
    }
  }
</style>
