// Importer l'URL de base de l'API depuis config.ts
import { API_BASE_URL } from './config';

// Configuration pour le backoff exponentiel
const RETRY_CONFIG = {
  maxRetries: 3,           // Nombre maximum de tentatives
  initialDelay: 1000,      // Délai initial en ms (1 seconde)
  maxDelay: 30000,         // Délai maximum en ms (30 secondes)
  backoffFactor: 2,        // Facteur de multiplication pour le backoff exponentiel
  statusCodesToRetry: [429, 503, 504] // Codes d'erreur HTTP à réessayer
};

// Création d'un objet API pour faciliter les appels
export const api = {
  get: (url: string, options: RequestInit = {}) => fetchWithAuth(url, { ...options, method: 'GET' }),
  post: (url: string, data: any, options: RequestInit = {}) => fetchWithAuth(url, { 
    ...options, 
    method: 'POST',
    body: JSON.stringify(data)
  }),
  put: (url: string, data: any, options: RequestInit = {}) => fetchWithAuth(url, { 
    ...options, 
    method: 'PUT',
    body: JSON.stringify(data)
  }),
  delete: (url: string, options: RequestInit = {}) => fetchWithAuth(url, { ...options, method: 'DELETE' }),
}

// Fonction pour obtenir le token d'authentification
export function getToken(): string | null {
  return localStorage.getItem("agent_token") || localStorage.getItem("token")
}

// Fonction pour définir le token d'authentification
export function setToken(token: string): void {
  localStorage.setItem("agent_token", token)
  localStorage.setItem("token", token) // Pour la compatibilité
}

// Fonction pour effacer le token d'authentification
export function clearToken(): void {
  localStorage.removeItem("agent_token")
  localStorage.removeItem("token")
  
  // Supprimer les autres données liées à l'authentification
  localStorage.removeItem("campaign_id")
  localStorage.removeItem("full_name")
  localStorage.removeItem("agent_phone_login")
  
  // Supprimer les cookies
  document.cookie = "jwt=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;"
  document.cookie = "auth_success=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;"
}

// Fonction pour vérifier si l'utilisateur est authentifié
export async function isAuthenticated(): Promise<boolean> {
  const token = getToken()
  if (!token) return false

  try {
    const response = await fetch(`${API_BASE_URL}/agent/auth/verify-token`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      credentials: "include",
    })

    return response.ok
  } catch (error) {
    console.error("Erreur lors de la vérification de l'authentification:", error)
    return false
  }
}

// Fonction pour vérifier l'authentification et récupérer les informations de l'utilisateur
export async function checkAuth(): Promise<{ authenticated: boolean; user?: any }> {
  const token = getToken()
  if (!token) return { authenticated: false }

  try {
    // Vérifier si nous sommes sur la page de login pour éviter les boucles infinies
    const isLoginPage = window.location.pathname === '/login';
    
    // Utiliser un fetch simple sans retry pour la page de login
    const response = await fetch(`${API_BASE_URL}/agent/info`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      credentials: "include",
    })

    if (response.ok) {
      const userData = await response.json()
      return { authenticated: true, user: userData }
    } else {
      // Si nous sommes sur la page de login et que nous recevons une erreur 429,
      // ne pas continuer à réessayer pour éviter une boucle infinie
      if (isLoginPage && response.status === 429) {
        console.warn('Trop de requêtes sur la page de login. Attente de 10 secondes avant de réessayer.');
        // Attendre 10 secondes avant de permettre une nouvelle tentative
        await new Promise(resolve => setTimeout(resolve, 10000));
      }
      return { authenticated: false }
    }
  } catch (error) {
    console.error("Erreur lors de la vérification de l'authentification:", error)
    return { authenticated: false }
  }
}

// Fonction utilitaire pour attendre un délai spécifié
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Fonction pour calculer le délai de backoff exponentiel
const calculateBackoff = (attempt: number): number => {
  const backoff = RETRY_CONFIG.initialDelay * Math.pow(RETRY_CONFIG.backoffFactor, attempt);
  return Math.min(backoff, RETRY_CONFIG.maxDelay);
};

// Fonction pour effectuer une requête authentifiée avec backoff exponentiel
export async function fetchWithAuth(url: string, options: RequestInit = {}): Promise<Response> {
  const token = getToken();

  if (!token) {
    throw new Error("Non authentifié");
  }

  const headers = new Headers(options.headers);
  headers.set("Authorization", `Bearer ${token}`);
  
  if (!headers.has("Content-Type") && !(options.body instanceof FormData)) {
    headers.set("Content-Type", "application/json");
  }

  const fullUrl = url.startsWith("http") ? url : `${API_BASE_URL}${url}`;
  let lastResponse: Response | null = null;
  let attempt = 0;
  
  // Vérifier si nous sommes sur la page de login pour éviter les boucles infinies
  const isLoginPage = window.location.pathname === '/login';
  
  // Si nous sommes sur la page de login, limiter le nombre de tentatives à 1
  const maxRetries = isLoginPage ? 0 : RETRY_CONFIG.maxRetries;

  while (attempt <= maxRetries) {
    try {
      // Si ce n'est pas la première tentative, attendre selon le backoff exponentiel
      if (attempt > 0) {
        const backoffTime = calculateBackoff(attempt - 1);
        console.log(`Tentative ${attempt}/${maxRetries} pour ${fullUrl} - Attente de ${backoffTime}ms...`);
        await delay(backoffTime);
      }

      // Effectuer la requête
      lastResponse = await fetch(fullUrl, {
        ...options,
        headers,
        credentials: "include",
      });

      // Gérer les erreurs d'authentification immédiatement
      if (lastResponse.status === 401) {
        clearToken();
        window.location.href = "/login";
        throw new Error("Session expirée");
      }

      // Si c'est une erreur à réessayer (429, 503, 504), continuer la boucle
      if (RETRY_CONFIG.statusCodesToRetry.includes(lastResponse.status)) {
        // Si nous sommes sur la page de login et que nous recevons une erreur 429,
        // ne pas continuer à réessayer pour éviter une boucle infinie
        if (isLoginPage && lastResponse.status === 429) {
          console.warn('Trop de requêtes sur la page de login. Pas de nouvelle tentative.');
          return lastResponse;
        }
        
        // Si c'est la dernière tentative, retourner la réponse même avec erreur
        if (attempt === maxRetries) {
          console.warn(`Échec après ${attempt} tentatives pour ${fullUrl}`);
          return lastResponse;
        }
        
        // Récupérer le header Retry-After s'il existe (pour 429)
        const retryAfter = lastResponse.headers.get('Retry-After');
        if (retryAfter) {
          const retryTime = parseInt(retryAfter) * 1000; // Convertir en ms
          console.log(`Header Retry-After détecté: attente de ${retryTime}ms`);
          await delay(retryTime);
          attempt++;
          continue;
        }
        
        // Sinon, passer à la tentative suivante avec backoff exponentiel
        attempt++;
        continue;
      }

      // Si la réponse est OK ou une erreur non retriable, la retourner immédiatement
      return lastResponse;
    } catch (error) {
      // En cas d'erreur réseau, réessayer si ce n'est pas la dernière tentative
      console.error(`Erreur réseau lors de la tentative ${attempt}:`, error);
      if (attempt === maxRetries) {
        throw error; // Relancer l'erreur si c'est la dernière tentative
      }
      attempt++;
    }
  }

  // Ce code ne devrait jamais être atteint, mais TypeScript l'exige
  return lastResponse!;
}

// Fonction pour se déconnecter
export function logout(): void {
  const token = getToken()

  if (token) {
    try {
      // Appel asynchrone pour informer le serveur de la déconnexion
      fetch(`${API_BASE_URL}/agent/auth/logout`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        credentials: "include",
      }).catch(error => {
        console.error("Erreur lors de la déconnexion:", error)
      })
    } catch (error) {
      console.error("Erreur lors de la déconnexion:", error)
    }
  }

  clearToken()
  window.location.href = "/login"
}
