<script lang="ts">
  import { onMount, afterUpdate } from 'svelte';
  import { agentState, pauseAgent, resumeAgent, AGENT_STATUSES } from '../stores/agent';
  import { agentStatus, updateStatus, setAgentReady, setAgentPaused, setAgentLogout, syncStateWithAgentStatus, syncAgentStatusWithState } from '../stores/agentStatus';
  import { api } from '../utils/fetchWithAuth';
  import { canMakeApiCall, recordApiCall } from '../utils/apiThrottle';
  
  // Props
  export let onPauseClick: () => void;
  
  // Utiliser directement le nouveau store agentStatus avec le préfixe $ pour une réactivité automatique
  // Cela garantit que les changements du store sont immédiatement reflétés dans le composant
  $: console.log('StatusButtons - Statut actuel:', $agentStatus.status);
  
  // Nous utilisons maintenant l'utilitaire apiThrottle pour la limitation des appels API
  
  // Fonction pour mettre l'agent en statut prêt
  async function handleReady() {
    console.log('StatusButtons - Clic sur bouton Prêt');
    
    if ($agentStatus.status !== AGENT_STATUSES.READY && !$agentStatus.callActive) {
      try {
        console.log('Changement de statut vers READY');
        
        // Mettre à jour les deux stores localement (sans appel API)
        updateStatus(AGENT_STATUSES.READY);
        setAgentReady();
        
        // Synchroniser les deux stores pour une mise à jour immédiate de l'interface
        syncStateWithAgentStatus();
        
        // Vérifier si on peut faire un appel API
        if (!canMakeApiCall()) {
          console.log('Mise à jour du statut côté serveur reportée - Trop d\'appels récents');
          return;
        }
        
        // Appel API
        console.log('Envoi du statut READY au serveur');
        const response = await api.post('/agent/status', {
          status: AGENT_STATUSES.READY
        });
        
        if (!response.ok) {
          console.error('Erreur lors de la mise en statut prêt côté serveur:', response.status);
        }
      } catch (err) {
        console.error('Erreur lors de la mise en statut prêt:', err);
      }
    }
  }
  
  // Fonction pour ouvrir le modal de pause
  function handlePause() {
    console.log('StatusButtons - Clic sur bouton Pause');
    
    if (!$agentStatus.callActive) {
      onPauseClick();
    }
  }
  
  // Fonction pour déconnecter l'agent
  async function handleLogout() {
    console.log('StatusButtons - Clic sur bouton Déconnexion');
    
    if (!$agentStatus.callActive) {
      try {
        console.log('Changement de statut vers LOGOUT');
        
        // Mettre à jour les deux stores localement (sans appel API)
        updateStatus(AGENT_STATUSES.LOGOUT);
        setAgentLogout();
        
        // Synchroniser les deux stores pour une mise à jour immédiate de l'interface
        syncStateWithAgentStatus();
        
        // Vérifier si on peut faire un appel API
        if (!canMakeApiCall()) {
          console.log('Mise à jour du statut côté serveur reportée - Trop d\'appels récents');
          return;
        }
        
        // Appel API
        console.log('Envoi du statut OFFLINE au serveur');
        const response = await api.post('/agent/status', {
          status: AGENT_STATUSES.OFFLINE
        });
        
        if (!response.ok) {
          console.error('Erreur lors de la déconnexion côté serveur:', response.status);
        }
      } catch (err) {
        console.error('Erreur lors de la déconnexion:', err);
      }
    }
  }
  
  // Après chaque mise à jour du composant
  afterUpdate(() => {
    console.log('StatusButtons - afterUpdate - Statut actuel:', status);
  });
</script>

<div class="status-buttons-container d-flex justify-content-center gap-3 mt-2">
  <!-- Bouton Prêt -->
  <button 
    class="status-icon-btn ready {$agentStatus.status === AGENT_STATUSES.READY ? 'active' : ''}" 
    on:click={handleReady}
    disabled={$agentStatus.callActive}
    title="Prêt"
  >
    <i class="bi bi-check-circle-fill"></i>
  </button>
  
  <!-- Bouton Pause -->
  <button 
    class="status-icon-btn pause {$agentStatus.status === AGENT_STATUSES.PAUSED ? 'active' : ''}" 
    on:click={handlePause}
    disabled={$agentStatus.callActive}
    title="Pause"
  >
    <i class="bi bi-pause-circle-fill"></i>
  </button>
  
  <!-- Bouton Déconnexion -->
  <button 
    class="status-icon-btn logout {$agentStatus.status === AGENT_STATUSES.LOGOUT ? 'active' : ''}" 
    on:click={handleLogout}
    disabled={$agentStatus.callActive}
    title="Déconnexion"
  >
    <i class="bi bi-box-arrow-right"></i>
  </button>
</div>

<style>
  .status-icon-btn {
    width: 3rem;
    height: 3rem;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 2px solid transparent;
    background-color: #f9fafb;
    color: #6b7280;
    font-size: 1.5rem;
    transition: all 0.15s ease;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  
  .status-icon-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
  
  .status-icon-btn.ready {
    color: #10b981;
    border-color: rgba(16, 185, 129, 0.3);
  }
  
  .status-icon-btn.ready:hover:not(:disabled) {
    background-color: rgba(16, 185, 129, 0.1);
  }
  
  .status-icon-btn.ready.active {
    background-color: #10b981;
    color: white;
    border-color: #10b981;
    box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.2);
    animation: pulse-green 2s infinite;
  }
  
  .status-icon-btn.pause {
    color: #f59e0b;
  }
  
  .status-icon-btn.pause:hover:not(:disabled) {
    background-color: rgba(245, 158, 11, 0.1);
  }
  
  .status-icon-btn.pause.active {
    background-color: #f59e0b;
    color: white;
    border-color: #f59e0b;
    box-shadow: 0 0 0 2px rgba(245, 158, 11, 0.2);
    animation: pulse-yellow 2s infinite;
  }
  
  .status-icon-btn.logout {
    color: #ef4444;
  }
  
  .status-icon-btn.logout:hover:not(:disabled) {
    background-color: rgba(239, 68, 68, 0.1);
  }
  
  .status-icon-btn.logout.active {
    background-color: #ef4444;
    color: white;
    border-color: #ef4444;
    box-shadow: 0 0 0 2px rgba(239, 68, 68, 0.2);
    animation: pulse-red 2s infinite;
  }
  
  @keyframes pulse-green {
    0% {
      box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.4);
    }
    70% {
      box-shadow: 0 0 0 10px rgba(16, 185, 129, 0);
    }
    100% {
      box-shadow: 0 0 0 0 rgba(16, 185, 129, 0);
    }
  }
  
  @keyframes pulse-yellow {
    0% {
      box-shadow: 0 0 0 0 rgba(245, 158, 11, 0.4);
    }
    70% {
      box-shadow: 0 0 0 10px rgba(245, 158, 11, 0);
    }
    100% {
      box-shadow: 0 0 0 0 rgba(245, 158, 11, 0);
    }
  }
  
  @keyframes pulse-red {
    0% {
      box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.4);
    }
    70% {
      box-shadow: 0 0 0 10px rgba(239, 68, 68, 0);
    }
    100% {
      box-shadow: 0 0 0 0 rgba(239, 68, 68, 0);
    }
  }
</style>
