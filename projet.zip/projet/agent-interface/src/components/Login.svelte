<script lang="ts">
  import { onMount } from 'svelte';
  import { agentState } from '../stores/agent';
  import { getToken, setToken, isAuthenticated } from '../utils/fetchWithAuth';
  import { API_BASE_URL } from '../utils/config';
  
  // Étape actuelle du processus de connexion
  enum LoginStep {
    PHONE = 1,
    USER = 2,
    CAMPAIGN = 3
  }
  
  // Variables pour le formulaire de connexion téléphonique (étape 1)
  let phoneLogin = '';
  let phonePassword = '';
  
  // Variables pour le formulaire de connexion utilisateur (étape 2)
  let userLogin = '';
  let userPassword = '';
  
  // Variables pour la sélection de campagne (étape 3)
  let selectedCampaignId = '';
  let campaigns: Campaign[] = [];
  
  // Interface pour les campagnes
  interface Campaign {
    id: string;
    name: string;
    description?: string;
    active: boolean;
  }
  
  // Variables générales
  let currentStep = LoginStep.PHONE;
  let rememberMe = false;
  let isLoading = false;
  let errorMessage = '';
  let phoneSessionToken = '';
  let userSessionToken = '';
  
  // Fonction pour gérer la connexion téléphonique (étape 1)
  async function handlePhoneLogin() {
    if (!phoneLogin || !phonePassword) {
      errorMessage = 'Veuillez saisir votre identifiant et mot de passe téléphonique';
      return;
    }
    
    try {
      isLoading = true;
      errorMessage = '';
      
      // Appel API au backend pour l'authentification téléphonique
      const response = await fetch(`${API_BASE_URL}/agent/auth/phone-login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ phoneLogin, phonePassword }),
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        
        // Stocker le token de session téléphonique temporaire
        if (data.phoneSessionToken) {
          phoneSessionToken = data.phoneSessionToken;
          
          // Passer à l'étape suivante (connexion utilisateur)
          currentStep = LoginStep.USER;
        } else {
          throw new Error('Token de session téléphonique non reçu');
        }
      } else {
        // Gérer les différents codes d'erreur
        if (response.status === 401) {
          errorMessage = 'Identifiant ou mot de passe téléphonique incorrect';
        } else {
          const errorData = await response.json().catch(() => ({}));
          errorMessage = errorData.message || 'Échec de la connexion téléphonique';
        }
      }
    } catch (error: any) {
      console.error('Erreur de connexion téléphonique:', error);
      errorMessage = error.message || 'Une erreur est survenue lors de la connexion téléphonique';
    } finally {
      isLoading = false;
    }
  }
  
  // Fonction pour gérer la connexion utilisateur (étape 2)
  async function handleUserLogin() {
    if (!userLogin || !userPassword) {
      errorMessage = 'Veuillez saisir votre identifiant et mot de passe utilisateur';
      return;
    }
    
    try {
      isLoading = true;
      errorMessage = '';
      
      // Appel API au backend pour l'authentification utilisateur
      const response = await fetch(`${API_BASE_URL}/agent/auth/user-login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${phoneSessionToken}`
        },
        body: JSON.stringify({ userLogin, userPassword }),
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        
        // Stocker le token de session utilisateur
        if (data.userSessionToken) {
          userSessionToken = data.userSessionToken;
        } else {
          throw new Error('Token de session utilisateur non reçu');
        }
        
        // Récupérer la liste des campagnes disponibles
        campaigns = data.campaigns || [];
        
        if (campaigns.length > 0) {
          // Passer à l'étape suivante (sélection de campagne)
          currentStep = LoginStep.CAMPAIGN;
        } else {
          errorMessage = 'Aucune campagne disponible pour cet utilisateur';
        }
      } else {
        // Gérer les différents codes d'erreur
        if (response.status === 401) {
          errorMessage = 'Identifiant ou mot de passe utilisateur incorrect';
        } else {
          const errorData = await response.json().catch(() => ({}));
          errorMessage = errorData.message || 'Échec de la connexion utilisateur';
        }
      }
    } catch (error: any) {
      console.error('Erreur de connexion utilisateur:', error);
      errorMessage = error.message || 'Une erreur est survenue lors de la connexion utilisateur';
    } finally {
      isLoading = false;
    }
  }
  
  // Fonction pour finaliser la connexion avec la sélection de campagne (étape 3)
  async function handleCampaignSelection() {
    if (!selectedCampaignId) {
      errorMessage = 'Veuillez sélectionner une campagne';
      return;
    }
    
    try {
      isLoading = true;
      errorMessage = '';
      
      // Préparer les données pour l'appel API
      const requestBody = { campaignId: selectedCampaignId };
      
      // Appel API au backend pour finaliser la connexion avec la campagne sélectionnée
      const response = await fetch(`${API_BASE_URL}/agent/auth/select-campaign`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${userSessionToken}`
        },
        body: JSON.stringify(requestBody),
        credentials: 'include'
      });
      
      // Tenter de lire le corps de la réponse
      const responseText = await response.text();
      let data;
      
      try {
        // Convertir la réponse texte en JSON
        data = JSON.parse(responseText);
      } catch (jsonError) {
        console.error('Erreur de parsing JSON:', jsonError);
        errorMessage = 'Format de réponse invalide du serveur';
        isLoading = false;
        return;
      }
      
      if (response.ok && data) {
        // Stocker le token final
        if (data.token) {
          // Stocker le token dans le service d'authentification
          setToken(data.token);
          
          // Stocker les informations de l'agent
          localStorage.setItem('campaign_id', selectedCampaignId);
          localStorage.setItem('full_name', data.full_name || '');
          
          // Mettre à jour l'état de l'agent
          agentState.update(state => ({
            ...state,
            user: data.user || userLogin,
            fullName: data.full_name || '',
            phoneLogin: phoneLogin,
            campaignId: selectedCampaignId,
            campaignName: campaigns.find(c => c.id === selectedCampaignId)?.name || '',
            extension: data.extension || '',
            status: 'READY',
            statusSince: new Date()
          }));
          
          // Gérer l'option "Se souvenir de moi"
          if (rememberMe) {
            localStorage.setItem('agent_phone_login', phoneLogin);
            
            // Définir un cookie de longue durée (30 jours)
            const expirationDate = new Date();
            expirationDate.setDate(expirationDate.getDate() + 30);
            document.cookie = `remember_agent=true; expires=${expirationDate.toUTCString()}; path=/;`;
          } else {
            localStorage.removeItem('agent_phone_login');
            document.cookie = 'remember_agent=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
          }
          
          // Rediriger vers la page d'accueil
          window.location.href = '/';
        } else {
          console.error('Token final non reçu du serveur');
          errorMessage = 'Token d\'authentification non reçu du serveur';
        }
      } else {
        // Gérer les différents codes d'erreur
        if (data && data.message) {
          errorMessage = data.message || 'Échec de la sélection de campagne';
        } else {
          errorMessage = `Échec de la sélection de campagne (${response.status})`;
        }
      }
    } catch (error: any) {
      console.error('Erreur lors de la sélection de campagne:', error);
      errorMessage = error.message || 'Une erreur est survenue lors de la sélection de campagne';
    } finally {
      isLoading = false;
    }
  }
  
  // Fonction pour revenir à l'étape précédente
  function goBack() {
    if (currentStep === LoginStep.USER) {
      currentStep = LoginStep.PHONE;
      phoneSessionToken = '';
      userSessionToken = '';
    } else if (currentStep === LoginStep.CAMPAIGN) {
      currentStep = LoginStep.USER;
      userSessionToken = '';
    }
    errorMessage = '';
  }
  
  onMount(async () => {
    // Vérifier si l'utilisateur est déjà authentifié
    const authenticated = await isAuthenticated();
    
    if (authenticated) {
      // Si l'utilisateur est déjà authentifié, rediriger vers la page d'accueil
      window.location.href = '/';
      return;
    }
    
    // Récupérer le nom d'utilisateur si "Se souvenir de moi" était coché
    const savedPhoneLogin = localStorage.getItem('agent_phone_login');
    const hasRememberCookie = document.cookie.split(';').some(item => item.trim().startsWith('remember_agent='));
    
    if (savedPhoneLogin && hasRememberCookie) {
      phoneLogin = savedPhoneLogin;
      rememberMe = true;
    }
  });
</script>

<div class="login-container">
  <div class="login-card-wrapper container d-flex flex-column align-items-center justify-content-center">
    <div class="card login-card">
      <div class="card-body p-0">
        <!-- Left side with image -->
        <div class="row g-0">
          <div class="col-lg-5 d-none d-lg-block">
            <div class="login-image">
              <div class="overlay"></div>
              <div class="image-content">
                <div class="brand-logo">
                  <div class="logo-circle">M</div>
                </div>
                <h2 class="welcome-text">McDial</h2>
                <p class="welcome-subtext">Plateforme de gestion d'appels</p>
              </div>
            </div>
          </div>
          
          <!-- Right side with form -->
          <div class="col-lg-7">
            <div class="login-form-container p-4 p-lg-5">
              <!-- Mobile logo (visible only on small screens) -->
              <div class="text-center mb-4 d-lg-none">
                <div class="brand-logo-mobile">
                  <div class="logo-circle">M</div>
                </div>
                <h2 class="mb-1">McDial Agent</h2>
              </div>
              
              <h3 class="login-title mb-4">
                {#if currentStep === LoginStep.PHONE}
                  Connexion téléphonique
                {:else if currentStep === LoginStep.USER}
                  Connexion utilisateur
                {:else}
                  Sélection de campagne
                {/if}
              </h3>
              
              <!-- Progress steps -->
              <div class="progress-container mb-5">
                <div class="progress-bar">
                  <div class="progress-fill" style="width: {(currentStep - 1) * 50}%"></div>
                </div>
                <div class="progress-steps">
                  <div class="step-item {currentStep >= LoginStep.PHONE ? 'active' : ''}">
                    <div class="step-circle">
                      {#if currentStep > LoginStep.PHONE}
                        <i class="bi bi-check-lg"></i>
                      {:else}
                        1
                      {/if}
                    </div>
                    <div class="step-label">Téléphone</div>
                  </div>
                  
                  <div class="step-item {currentStep >= LoginStep.USER ? 'active' : ''}">
                    <div class="step-circle">
                      {#if currentStep > LoginStep.USER}
                        <i class="bi bi-check-lg"></i>
                      {:else}
                        2
                      {/if}
                    </div>
                    <div class="step-label">Utilisateur</div>
                  </div>
                  
                  <div class="step-item {currentStep >= LoginStep.CAMPAIGN ? 'active' : ''}">
                    <div class="step-circle">3</div>
                    <div class="step-label">Campagne</div>
                  </div>
                </div>
              </div>
              
              {#if errorMessage}
                <div class="alert alert-danger mb-4 fade show d-flex align-items-center" role="alert">
                  <i class="bi bi-exclamation-triangle-fill me-2"></i>
                  <div class="flex-grow-1">{errorMessage}</div>
                  <button type="button" class="btn-close" aria-label="Close" on:click={() => errorMessage = ''}></button>
                </div>
              {/if}
              
              <!-- Étape 1 : Connexion téléphonique -->
              {#if currentStep === LoginStep.PHONE}
                <form on:submit|preventDefault={handlePhoneLogin} class="mb-3">
                  <div class="form-group mb-4">
                    <label for="phoneLogin" class="form-label">Phone Login</label>
                    <div class="input-group">
                      <span class="input-group-text"><i class="bi bi-telephone"></i></span>
                      <input 
                        type="text" 
                        class="form-control custom-input" 
                        id="phoneLogin" 
                        placeholder="Entrez votre identifiant téléphonique"
                        bind:value={phoneLogin}
                        disabled={isLoading}
                        required
                      />
                    </div>
                  </div>
                  
                  <div class="form-group mb-4">
                    <label for="phonePassword" class="form-label">Phone Password</label>
                    <div class="input-group">
                      <span class="input-group-text"><i class="bi bi-lock"></i></span>
                      <input 
                        type="password" 
                        class="form-control custom-input" 
                        id="phonePassword" 
                        placeholder="Entrez votre mot de passe téléphonique"
                        bind:value={phonePassword}
                        disabled={isLoading}
                        required
                      />
                    </div>
                  </div>
                  
                  <div class="form-check mb-4">
                    <input 
                      class="form-check-input" 
                      type="checkbox" 
                      id="rememberMe"
                      bind:checked={rememberMe}
                    />
                    <label class="form-check-label" for="rememberMe">
                      Se souvenir de moi
                    </label>
                  </div>
                  
                  <button 
                    type="submit" 
                    class="btn btn-primary w-100 btn-login" 
                    disabled={isLoading}
                  >
                    {#if isLoading}
                      <span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                      Vérification en cours...
                    {:else}
                      Continuer
                      <i class="bi bi-arrow-right ms-2"></i>
                    {/if}
                  </button>
                </form>
              
              <!-- Étape 2 : Connexion utilisateur -->
              {:else if currentStep === LoginStep.USER}
                <form on:submit|preventDefault={handleUserLogin} class="mb-3">
                  <div class="form-group mb-4">
                    <label for="userLogin" class="form-label">Username</label>
                    <div class="input-group">
                      <span class="input-group-text"><i class="bi bi-person"></i></span>
                      <input 
                        type="text" 
                        class="form-control custom-input" 
                        id="userLogin" 
                        placeholder="Entrez votre nom d'utilisateur"
                        bind:value={userLogin}
                        disabled={isLoading}
                        required
                      />
                    </div>
                  </div>
                  
                  <div class="form-group mb-4">
                    <label for="userPassword" class="form-label">Password</label>
                    <div class="input-group">
                      <span class="input-group-text"><i class="bi bi-lock"></i></span>
                      <input 
                        type="password" 
                        class="form-control custom-input" 
                        id="userPassword" 
                        placeholder="Entrez votre mot de passe"
                        bind:value={userPassword}
                        disabled={isLoading}
                        required
                      />
                    </div>
                  </div>
                  
                  <div class="d-flex justify-content-between">
                    <button 
                      type="button" 
                      class="btn btn-outline-secondary flex-grow-1 me-2" 
                      on:click={goBack}
                      disabled={isLoading}
                    >
                      <i class="bi bi-arrow-left me-2"></i>
                      Retour
                    </button>
                    
                    <button 
                      type="submit" 
                      class="btn btn-primary flex-grow-1 btn-login" 
                      disabled={isLoading}
                    >
                      {#if isLoading}
                        <span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                        Vérification...
                      {:else}
                        Continuer
                        <i class="bi bi-arrow-right ms-2"></i>
                      {/if}
                    </button>
                  </div>
                </form>
              
              <!-- Étape 3 : Sélection de campagne -->
              {:else if currentStep === LoginStep.CAMPAIGN}
                <form on:submit|preventDefault={handleCampaignSelection} class="mb-3">
                  <div class="form-group mb-4">
                    <label for="campaignSelect" class="form-label">Sélectionner une campagne</label>
                    <div class="input-group">
                      <span class="input-group-text"><i class="bi bi-megaphone"></i></span>
                      <select 
                        id="campaignSelect" 
                        class="form-select campaign-select custom-input" 
                        bind:value={selectedCampaignId}
                        required
                      >
                        <option value="" disabled selected>-- Sélectionner une campagne --</option>
                        {#each campaigns as campaign}
                          {#if campaign.active !== false}
                            <option value={campaign.id}>{campaign.name}</option>
                          {/if}
                        {/each}
                      </select>
                    </div>
                  </div>
                  
                  {#if campaigns.length > 0 && selectedCampaignId}
                    {#each campaigns.filter(c => c.id === selectedCampaignId) as selectedCampaign}
                      <div class="campaign-info mt-3 p-3 mb-4">
                        <h6 class="mb-2">Détails de la campagne:</h6>
                        <div><strong>ID:</strong> {selectedCampaign.id}</div>
                        <div><strong>Nom:</strong> {selectedCampaign.name}</div>
                        {#if selectedCampaign.description}
                          <div><strong>Description:</strong> {selectedCampaign.description}</div>
                        {/if}
                      </div>
                    {/each}
                  {/if}
                  
                  <div class="d-flex justify-content-between">
                    <button 
                      type="button" 
                      class="btn btn-outline-secondary flex-grow-1 me-2" 
                      on:click={goBack}
                      disabled={isLoading}
                    >
                      <i class="bi bi-arrow-left me-2"></i>
                      Retour
                    </button>
                    
                    <button 
                      type="submit" 
                      class="btn btn-primary flex-grow-1 btn-login" 
                      disabled={isLoading}
                    >
                      {#if isLoading}
                        <span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                        Connexion...
                      {:else}
                        Se connecter
                        <i class="bi bi-box-arrow-in-right ms-2"></i>
                      {/if}
                    </button>
                  </div>
                </form>
              {/if}
              
              <!-- Footer -->
              <div class="text-center mt-4 text-muted small">
                <p>© {new Date().getFullYear()} McDial. All rights reserved.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<style>
 /* Custom styling for the login page */
 .login-container {
   background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
   min-height: 100vh;
   padding: 2rem 1rem;
   display: flex;
   align-items: center;
   justify-content: center;
 }
 
 .login-card-wrapper {
   width: 100%;
   max-width: 1000px;
 }
 
 .login-card {
   border-radius: 16px;
   overflow: hidden;
   box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
   border: none;
   transition: all 0.3s ease;
 }
 
 /* Left side with image */
 .login-image {
   background: linear-gradient(45deg, #1a56db, #4f46e5);
   height: 100%;
   position: relative;
   overflow: hidden;
   display: flex;
   align-items: center;
   justify-content: center;
 }
 
 .login-image::before {
   content: '';
   position: absolute;
   top: -50%;
   left: -50%;
   width: 200%;
   height: 200%;
   background: radial-gradient(circle, rgba(255,255,255,0.1) 10%, transparent 10.5%),
               radial-gradient(circle, rgba(255,255,255,0.1) 10%, transparent 10.5%);
   background-size: 20px 20px;
   background-position: 0 0, 10px 10px;
   transform: rotate(45deg);
   animation: moveBackground 60s linear infinite;
 }
 
 @keyframes moveBackground {
   0% {
     background-position: 0 0, 10px 10px;
   }
   100% {
     background-position: 500px 500px, 510px 510px;
   }
 }
 
 .overlay {
   position: absolute;
   top: 0;
   left: 0;
   right: 0;
   bottom: 0;
   background: rgba(0, 0, 0, 0.2);
 }
 
 .image-content {
   position: relative;
   z-index: 2;
   text-align: center;
   color: white;
   padding: 2rem;
 }
 
 .brand-logo {
   display: flex;
   justify-content: center;
   margin-bottom: 1.5rem;
 }
 
 .brand-logo-mobile {
   display: flex;
   justify-content: center;
   margin-bottom: 1rem;
 }
 
 .logo-circle {
   width: 70px;
   height: 70px;
   border-radius: 50%;
   display: flex;
   align-items: center;
   justify-content: center;
   font-size: 2rem;
   font-weight: bold;
   color: white;
   background: linear-gradient(45deg, #1a56db, #4f46e5);
   box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
 }
 
 .welcome-text {
   font-size: 2.5rem;
   font-weight: 700;
   margin-bottom: 0.5rem;
   text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
 }
 
 .welcome-subtext {
   font-size: 1.1rem;
   opacity: 0.9;
 }
 
 /* Right side with form */
 .login-form-container {
   height: 100%;
 }
 
 .login-title {
   font-weight: 600;
   color: #333;
   margin-bottom: 1.5rem;
 }
 
 /* Progress steps styling */
 .progress-container {
   position: relative;
   margin-bottom: 2rem;
 }
 
 .progress-bar {
   height: 4px;
   background-color: #e9ecef;
   border-radius: 2px;
   margin-bottom: 1.5rem;
   position: relative;
   z-index: 1;
 }
 
 .progress-fill {
   position: absolute;
   top: 0;
   left: 0;
   height: 100%;
   background: linear-gradient(to right, #1a56db, #4f46e5);
   border-radius: 2px;
   transition: width 0.5s ease;
 }
 
 .progress-steps {
   display: flex;
   justify-content: space-between;
   position: relative;
   z-index: 2;
 }
 
 .step-item {
   display: flex;
   flex-direction: column;
   align-items: center;
   position: relative;
   width: 33.333%;
 }
 
 .step-circle {
   width: 36px;
   height: 36px;
   border-radius: 50%;
   background-color: white;
   display: flex;
   align-items: center;
   justify-content: center;
   margin-bottom: 0.5rem;
   color: #6c757d;
   font-size: 0.9rem;
   font-weight: 600;
   transition: all 0.3s ease;
   border: 2px solid #e9ecef;
   position: relative;
   top: -20px;
 }
 
 .step-item.active .step-circle {
   background: linear-gradient(45deg, #1a56db, #4f46e5);
   color: white;
   border-color: white;
   transform: scale(1.1);
   box-shadow: 0 0 0 5px rgba(26, 86, 219, 0.2);
 }
 
 .step-label {
   font-size: 0.85rem;
   color: #6c757d;
   font-weight: 500;
   transition: all 0.3s ease;
   text-align: center;
 }
 
 .step-item.active .step-label {
   color: #1a56db;
   font-weight: 600;
 }
 
 /* Form styling */
 .form-group {
   margin-bottom: 1.5rem;
 }
 
 .form-label {
   font-weight: 500;
   margin-bottom: 0.5rem;
   color: #495057;
 }
 
 .input-group {
   border-radius: 8px;
   overflow: hidden;
   box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
   transition: all 0.3s ease;
 }
 
 .input-group:focus-within {
   box-shadow: 0 0 0 3px rgba(26, 86, 219, 0.25);
 }
 
 .input-group-text {
   background-color: #f8f9fa;
   border: 1px solid #ced4da;
   border-right: none;
   color: #6c757d;
   padding-left: 1rem;
   padding-right: 1rem;
 }
 
 .custom-input {
   border-radius: 0 8px 8px 0;
   padding: 0.75rem 1rem;
   border: 1px solid #ced4da;
   border-left: none;
   transition: all 0.3s ease;
   font-size: 1rem;
 }
 
 .custom-input:focus {
   border-color: #1a56db;
   box-shadow: none;
   outline: none;
 }
 
 .btn-login {
   border-radius: 8px;
   padding: 0.75rem 1.5rem;
   font-weight: 600;
   letter-spacing: 0.5px;
   transition: all 0.3s ease;
   background: linear-gradient(45deg, #1a56db, #4f46e5);
   border: none;
 }
 
 .btn-login:hover {
   transform: translateY(-2px);
   box-shadow: 0 5px 15px rgba(26, 86, 219, 0.4);
   background: linear-gradient(45deg, #164fc6, #4338ca);
 }
 
 .btn-login:active {
   transform: translateY(0);
 }
 
 /* Campaign select styling */
 .campaign-select {
   padding: 0.75rem 1rem;
   border-radius: 0 8px 8px 0;
   border: 1px solid #ced4da;
   border-left: none;
   background-color: #fff;
   transition: all 0.3s ease;
   font-size: 1rem;
   height: auto;
 }
 
 .campaign-select:focus {
   border-color: #1a56db;
   box-shadow: none;
   outline: none;
 }
 
 .campaign-info {
   background-color: #f0f4ff;
   border-radius: 8px;
   border: 1px solid #d1defa;
   color: #1a56db;
 }
 
 /* Responsive adjustments */
 @media (max-width: 991.98px) {
   .login-card-wrapper {
     max-width: 500px;
   }
   
   .login-card {
     box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
   }
   
   .logo-circle {
     width: 60px;
     height: 60px;
     font-size: 1.8rem;
   }
 }
</style>
