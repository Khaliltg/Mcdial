<script lang="ts">
  import { onMount, onDestroy } from 'svelte';
  import { agentState, statusDuration, callDuration, AGENT_STATUSES } from '../stores/agent';
  import { agentStatus, syncAgentStatusWithState, syncStateWithAgentStatus } from '../stores/agentStatus';
  import { formatTime } from '../utils/timeUtils';
  import { logout } from '../utils/fetchWithAuth';
  import { canMakeApiCall, recordApiCall } from '../utils/apiThrottle';
  import { api } from '../utils/fetchWithAuth';
  
  // Variables d'état UI
  let currentDateTime = new Date();
  let dateTimeInterval: number;
  let statusSyncInterval: number; // Intervalle pour la synchronisation du statut
  // Nous utilisons maintenant l'utilitaire apiThrottle pour la limitation des appels API
  let showNotifications = false;
  let showStatsDetails = false;
  
  // Configuration des statuts d'agent avec couleurs et icônes
  const statusConfig = {
    [AGENT_STATUSES.READY]: {
      color: '#10b981',
      bgColor: 'rgba(16, 185, 129, 0.1)',
      icon: 'bi-check-circle-fill',
      label: 'Prêt',
      description: 'Prêt à recevoir des appels'
    },
    [AGENT_STATUSES.PAUSED]: {
      color: '#f59e0b',
      bgColor: 'rgba(245, 158, 11, 0.1)',
      icon: 'bi-pause-circle-fill',
      label: 'En pause',
      description: 'En pause'
    },
    [AGENT_STATUSES.DIALING]: {
      color: '#0ea5e9',
      bgColor: 'rgba(14, 165, 233, 0.1)',
      icon: 'bi-telephone-outbound-fill',
      label: 'Numérotation',
      description: 'Appel en cours...'
    },
    [AGENT_STATUSES.INCALL]: {
      color: '#ef4444',
      bgColor: 'rgba(239, 68, 68, 0.1)',
      icon: 'bi-telephone-fill',
      label: 'En appel',
      description: 'En communication'
    },
    [AGENT_STATUSES.WAITING]: {
      color: '#8b5cf6',
      bgColor: 'rgba(139, 92, 246, 0.1)',
      icon: 'bi-hourglass-split',
      label: 'En attente',
      description: 'En attente'
    },
    [AGENT_STATUSES.LOGOUT]: {
      color: '#6b7280',
      bgColor: 'rgba(107, 114, 128, 0.1)',
      icon: 'bi-x-circle-fill',
      label: 'Déconnecté',
      description: 'Hors ligne'
    }
  };
  
  // Variables réactives pour le statut actuel - utiliser agentStatus au lieu de agentState
  $: currentStatus = $agentStatus.status;
  $: isCallActive = $agentStatus.callActive;
  $: pauseReason = $agentStatus.pauseReason;
  
  // Forcer le rafraîchissement de l'interface à chaque changement de statut
  $: {
    // Cette expression réactive se déclenche à chaque changement de $agentStatus.status
    if ($agentStatus.status) {
      console.log('StatusBar - Rafraîchissement forcé du statut:', $agentStatus.status);
      // La fonction vide ci-dessous force Svelte à ré-évaluer les expressions réactives
      setTimeout(() => {}, 0);
    }
  }
  
  /**
   * Synchronise le statut de l'agent avec le serveur et met à jour les stores locaux
   * Utilise le mécanisme de limitation des appels API pour éviter les erreurs 429
   */
  async function forceStatusSync() {
    // Vérifier si on peut faire un appel API avec notre utilitaire partagé
    if (!canMakeApiCall()) {
      console.log('StatusBar - Synchronisation ignorée - Trop d\'appels récents');
      return;
    }
    
    console.log('StatusBar - Synchronisation du statut...');
    
    // Synchroniser d'abord les stores localement pour une mise à jour immédiate de l'UI
    syncAgentStatusWithState();
    
    try {
      // Appel API pour récupérer les informations agent du serveur
      const response = await api.get('/agent/info');
      
      if (response.ok) {
        const agentInfo = await response.json();
        
        // Mettre à jour le store agentStatus avec les données du serveur
        agentStatus.update(current => ({
          ...current,
          status: agentInfo.status,
          pauseCode: agentInfo.pause_code,
          pauseReason: agentInfo.pause_reason,
          callActive: agentInfo.in_call === true
        }));
        
        // Synchroniser agentState avec agentStatus
        syncStateWithAgentStatus();
        
        console.log('StatusBar - Statut après synchronisation:', $agentStatus.status);
      } else {
        console.error('StatusBar - Erreur lors de la synchronisation:', response.status);
      }
    } catch (error) {
      console.error('StatusBar - Erreur lors de la synchronisation:', error);
    }
    
    // Enregistrer l'appel API pour la limitation de débit
    recordApiCall();
  }
  
  // Notifications d'exemple
  let notifications = [
    { id: 1, title: 'Nouvel appel manqué', message: 'Vous avez manqué un appel de +33612345678', time: '10:30', read: false },
    { id: 2, title: 'Pause déjeuner', message: 'Votre pause déjeuner est programmée à 12:30', time: '09:15', read: true }
  ];
  
  // Mettre à jour la date et l'heure actuelles
  function updateDateTime() {
    currentDateTime = new Date();
  }

  // Obtenir la configuration du statut actuel
  function getStatusConfig() {
    // Utiliser directement $agentStatus.status pour une mise à jour immédiate
    const status = $agentStatus.status || AGENT_STATUSES.LOGOUT;
    console.log('StatusBar - getStatusConfig - statut actuel:', status);
    return statusConfig[status] || statusConfig[AGENT_STATUSES.LOGOUT];
  }

  // Basculer le panneau de notifications
  function toggleNotifications() {
    showNotifications = !showNotifications;
  }

  // Basculer les détails des statistiques
  function toggleStatsDetails() {
    showStatsDetails = !showStatsDetails;
  }

  // Obtenir le nombre de notifications non lues
  function getUnreadNotificationsCount(): number {
    return notifications.filter(n => !n.read).length;
  }

  // Marquer une notification comme lue
  function markAsRead(id: number) {
    notifications = notifications.map(n => 
      n.id === id ? { ...n, read: true } : n
    );
  }

  // Effacer toutes les notifications
  function clearAllNotifications() {
    notifications = notifications.map(n => ({ ...n, read: true }));
  }

  // Fonction de déconnexion
  function handleLogout() {
    if (window.confirm('Êtes-vous sûr de vouloir vous déconnecter?')) {
      logout();
    }
  }

  // Configurer les minuteries au montage du composant
  onMount(() => {
    // Mettre à jour l'horloge
    dateTimeInterval = window.setInterval(updateDateTime, 1000);
    updateDateTime();
    
    // Configurer l'intervalle de synchronisation du statut (toutes les 10 secondes)
    // Utiliser un intervalle légèrement différent du Dashboard pour éviter les appels simultanés
    statusSyncInterval = window.setInterval(forceStatusSync, 10000);
    
    // Synchroniser le statut immédiatement
    forceStatusSync();
    
    console.log('StatusBar - Intervalles de synchronisation configurés');
  });

  // Nettoyer les minuteries à la destruction du composant
  onDestroy(() => {
    if (dateTimeInterval) clearInterval(dateTimeInterval);
    if (statusSyncInterval) clearInterval(statusSyncInterval);
    console.log('StatusBar - Intervalles nettoyés');
  });
</script>

<div class="status-bar">
  <div class="status-bar-content">
    <!-- Section gauche: Profil utilisateur -->
    <div class="user-profile">
      <div class="avatar-container">
        <div class="avatar" style="background-color: {getStatusConfig().bgColor}; color: {getStatusConfig().color}">
          {$agentState.fullName ? $agentState.fullName.charAt(0).toUpperCase() : 'A'}
        </div>
        <span class="status-indicator" style="background-color: {getStatusConfig().color}"></span>
      </div>
      
      <div class="user-info">
        <div class="user-name">{$agentState.fullName || 'Agent'}</div>
        <div class="user-extension">
          {$agentState.isAuthenticated 
            ? ($agentState.extension ? `Ext. ${$agentState.extension}` : 'Connecté') 
            : 'Non connecté'}
        </div>
      </div>
    </div>
    
    <!-- Section centrale: Statut et campagne -->
    <div class="status-campaign">
      <!-- Affichage du statut -->
      <div class="status-display" style="background-color: {getStatusConfig().bgColor}; color: {getStatusConfig().color}">
        <i class="bi {getStatusConfig().icon}"></i>
        <span class="status-label">{getStatusConfig().label}</span>
        <span class="status-duration">{formatTime($statusDuration)}</span>
        <span class="status-description">{getStatusConfig().description}</span>
      </div>
      
      <!-- Informations de campagne -->
      <div class="campaign-info">
        <div class="campaign-section">
          <div class="info-label">Campagne</div>
          <div class="info-value campaign-name">{$agentState.campaignName || 'Aucune campagne'}</div>
        </div>
        
        <div class="campaign-section">
          <div class="info-label">ID</div>
          <div class="info-value">{$agentState.campaignId || 'N/A'}</div>
        </div>
        
        <div class="campaign-section">
          <div class="info-label">Extension</div>
          <div class="info-value">{$agentState.extension || 'N/A'}</div>
        </div>
      </div>
    </div>
    
    <!-- Section droite: Informations d'appel et actions -->
    <div class="call-actions">
      <!-- Informations d'appel -->
      {#if currentStatus === AGENT_STATUSES.INCALL}
        <div class="call-info">
          <div class="info-label">Appel en cours</div>
          <div class="call-duration">
            <i class="bi bi-telephone-fill"></i>
            <span>{formatTime($callDuration)}</span>
          </div>
        </div>
      {/if}
      
      <!-- Bouton de notifications -->
      <div class="notification-container">
        <button class="notification-button" on:click={toggleNotifications}>
          <i class="bi bi-bell"></i>
          {#if getUnreadNotificationsCount() > 0}
            <span class="notification-badge">{getUnreadNotificationsCount()}</span>
          {/if}
        </button>
        
        <!-- Panneau de notifications -->
        {#if showNotifications}
          <div class="notification-panel">
            <div class="notification-header">
              <h6>Notifications</h6>
              <button class="clear-button" on:click={clearAllNotifications}>
                Tout marquer comme lu
              </button>
            </div>
            
            <div class="notification-list">
              {#if notifications.length === 0}
                <div class="no-notifications">
                  Aucune notification
                </div>
              {:else}
                {#each notifications as notification}
                  <div 
                    class="notification-item {!notification.read ? 'unread' : ''}" 
                    on:click={() => markAsRead(notification.id)}
                    role="button"
                    tabindex="0"
                    on:keydown={e => e.key === 'Enter' && markAsRead(notification.id)}
                  >
                    <div class="notification-icon">
                      <i class="bi bi-envelope"></i>
                    </div>
                    <div class="notification-content">
                      <div class="notification-title">{notification.title}</div>
                      <div class="notification-message">{notification.message}</div>
                      <div class="notification-time">{notification.time}</div>
                    </div>
                    {#if !notification.read}
                      <div class="unread-indicator"></div>
                    {/if}
                  </div>
                {/each}
              {/if}
            </div>
          </div>
        {/if}
      </div>
      
      <!-- Bouton de déconnexion -->
      <button class="logout-button" on:click={handleLogout}>
        <i class="bi bi-box-arrow-right"></i>
        <span>Déconnexion</span>
      </button>
    </div>
  </div>
</div>

<style>
  /* Styles principaux */
  .status-bar {
    background: linear-gradient(90deg, #1e40af, #3b82f6); /* Fond bleu */
    color: white;
    padding: 0.5rem 0;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.15);
    width: 100%;
    position: relative;
    z-index: 100;
  }
  
  .status-bar-content {
    display: flex;
    align-items: center;
    justify-content: space-between;
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 1rem;
  }
  
  /* Section profil utilisateur */
  .user-profile {
    display: flex;
    align-items: center;
    flex: 0 0 auto;
    margin-right: 1rem;
  }
  
  .avatar-container {
    position: relative;
    margin-right: 0.75rem;
  }
  
  .avatar {
    width: 38px;
    height: 38px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    font-size: 1.1rem;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    background-color: white;
  }
  
  .status-indicator {
    position: absolute;
    bottom: 0;
    right: 0;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    border: 2px solid white;
  }
  
  .user-info {
    line-height: 1.2;
  }
  
  .user-name {
    font-weight: 600;
    font-size: 0.95rem;
  }
  
  .user-extension {
    font-size: 0.8rem;
    opacity: 0.8;
  }
  
  /* Section statut et campagne */
  .status-campaign {
    display: flex;
    align-items: center;
    flex: 1;
    justify-content: center;
    gap: 1rem;
  }
  
  .status-display {
    display: flex;
    align-items: center;
    padding: 0.4rem 0.8rem;
    border-radius: 20px;
    font-size: 0.9rem;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
    background-color: white;
  }
  
  .status-display i {
    margin-right: 0.5rem;
  }
  
  .status-label {
    font-weight: 600;
    margin-right: 0.5rem;
  }
  
  .status-duration {
    background-color: rgba(255, 255, 255, 0.2);
    padding: 0.1rem 0.4rem;
    border-radius: 10px;
    font-size: 0.8rem;
    margin-right: 0.5rem;
  }
  
  .status-description {
    font-size: 0.8rem;
    font-style: italic;
    opacity: 0.9;
  }
  
  .campaign-info {
    display: flex;
    background-color: rgba(255, 255, 255, 0.1);
    padding: 0.5rem 0.8rem;
    border-radius: 8px;
    gap: 1rem;
  }
  
  .campaign-section {
    display: flex;
    flex-direction: column;
  }
  
  .info-label {
    font-size: 0.7rem;
    opacity: 0.8;
    margin-bottom: 0.1rem;
  }
  
  .info-value {
    font-weight: 600;
    font-size: 0.9rem;
  }
  
  .campaign-name {
    max-width: 150px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  
  /* Section appel et actions */
  .call-actions {
    display: flex;
    align-items: center;
    flex: 0 0 auto;
    gap: 0.75rem;
  }
  
  .call-info {
    background-color: rgba(255, 255, 255, 0.1);
    padding: 0.4rem 0.8rem;
    border-radius: 8px;
    font-size: 0.9rem;
  }
  
  .call-duration {
    display: flex;
    align-items: center;
    font-weight: 600;
  }
  
  .call-duration i {
    color: #ef4444;
    margin-right: 0.4rem;
  }
  
  .notification-container {
    position: relative;
  }
  
  .notification-button {
    width: 34px;
    height: 34px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: rgba(255, 255, 255, 0.1);
    border: none;
    color: white;
    cursor: pointer;
    position: relative;
    transition: background-color 0.2s;
  }
  
  .notification-button:hover {
    background-color: rgba(255, 255, 255, 0.2);
  }
  
  .notification-badge {
    position: absolute;
    top: -5px;
    right: -5px;
    background-color: #ef4444;
    color: white;
    font-size: 0.7rem;
    width: 18px;
    height: 18px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 600;
    border: 2px solid #1e40af;
  }
  
  .notification-panel {
    position: absolute;
    top: calc(100% + 10px);
    right: 0;
    width: 300px;
    background-color: white;
    border-radius: 8px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    z-index: 1000;
    color: #333;
    overflow: hidden;
  }
  
  .notification-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.75rem 1rem;
    border-bottom: 1px solid #eee;
  }
  
  .notification-header h6 {
    margin: 0;
    font-weight: 600;
    font-size: 0.95rem;
  }
  
  .clear-button {
    background: none;
    border: none;
    color: #3b82f6;
    font-size: 0.8rem;
    cursor: pointer;
    padding: 0;
  }
  
  .notification-list {
    max-height: 300px;
    overflow-y: auto;
  }
  
  .no-notifications {
    padding: 1.5rem;
    text-align: center;
    color: #888;
    font-style: italic;
  }
  
  .notification-item {
    display: flex;
    padding: 0.75rem 1rem;
    border-bottom: 1px solid #eee;
    cursor: pointer;
    transition: background-color 0.2s;
  }
  
  .notification-item:hover {
    background-color: #f9fafb;
  }
  
  .notification-item.unread {
    background-color: #f0f7ff;
  }
  
  .notification-icon {
    margin-right: 0.75rem;
    color: #3b82f6;
  }
  
  .notification-content {
    flex: 1;
  }
  
  .notification-title {
    font-weight: 600;
    font-size: 0.9rem;
    margin-bottom: 0.2rem;
  }
  
  .notification-message {
    font-size: 0.85rem;
    color: #666;
    margin-bottom: 0.4rem;
  }
  
  .notification-time {
    font-size: 0.75rem;
    color: #888;
  }
  
  .unread-indicator {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background-color: #3b82f6;
    margin-left: 0.5rem;
    align-self: center;
  }
  
  .logout-button {
    display: flex;
    align-items: center;
    background-color: rgba(239, 68, 68, 0.1);
    color: white;
    border: 1px solid rgba(239, 68, 68, 0.3);
    border-radius: 6px;
    padding: 0.4rem 0.8rem;
    font-size: 0.9rem;
    cursor: pointer;
    transition: all 0.2s;
  }
  
  .logout-button:hover {
    background-color: rgba(239, 68, 68, 0.2);
  }
  
  .logout-button i {
    margin-right: 0.4rem;
  }
  
  /* Responsive */
  @media (max-width: 992px) {
    .status-bar-content {
      flex-direction: column;
      padding: 0.5rem;
    }
    
    .user-profile, .status-campaign, .call-actions {
      width: 100%;
      margin-bottom: 0.75rem;
    }
    
    .status-campaign {
      flex-direction: column;
      gap: 0.5rem;
    }
    
    .campaign-info {
      width: 100%;
      justify-content: space-between;
    }
  }
  
  @media (max-width: 576px) {
    .status-display {
      width: 100%;
      justify-content: center;
    }
    
    .status-description {
      display: none;
    }
    
    .campaign-info {
      flex-wrap: wrap;
    }
    
    .call-actions {
      justify-content: space-between;
    }
  }
</style>