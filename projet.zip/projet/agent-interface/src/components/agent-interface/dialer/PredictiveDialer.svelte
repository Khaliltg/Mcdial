<script lang="ts">
  import { onMount, onDestroy } from 'svelte';
  import { agentState, updateAgentStatus, startCall, endCall, resetCall, callDuration } from '../../../stores/agent';
  import ProspectForm from '../prospect/ProspectForm.svelte';
  
  // Props pour la communication avec les composants parents
  export let callEnded = false;
  
  // Variables d'état
  let predictiveMode = false;
  let waitingForCall = false;
  let errorMessage = '';
  let successMessage = '';
  let prospectData: any = null;
  
  // Numéros de campagne pour simulation
  interface CampaignNumber {
    phone_number: string;
    first_name: string;
    last_name: string;
    lead_id: string;
    called: boolean;
  }
  
  let campaignNumbers: CampaignNumber[] = [];
  
  // Fonction pour simuler la vérification des appels entrants
  function checkForIncomingCalls() {
    console.log('Vérification des appels entrants (simulée)');
    // Cette fonction est maintenant simulée et ne fait pas d'appels au backend
  }
  
  // Fonction pour simuler la fin d'un appel
  function handleEndCall() {
    console.log('Fin d\'appel simulée');
    
    // Mettre à jour l'interface utilisateur
    endCall();
    successMessage = 'Appel terminé avec succès';
    setTimeout(() => { successMessage = ''; }, 3000);
    
    // Réinitialiser l'état après un court délai
    setTimeout(() => {
      resetCall();
      prospectData = null;
    }, 2000);
  }
  
  // Fonction pour activer/désactiver le mode prédictif
  function togglePredictiveMode() {
    predictiveMode = !predictiveMode;
    
    if (predictiveMode) {
      // Simuler le démarrage du mode prédictif
      successMessage = 'Mode prédictif activé';
      setTimeout(() => { successMessage = ''; }, 3000);
      waitingForCall = true;
    } else {
      // Simuler l'arrêt du mode prédictif
      successMessage = 'Mode prédictif désactivé';
      setTimeout(() => { successMessage = ''; }, 3000);
      waitingForCall = false;
    }
  }
  
  // Fonction pour sauvegarder les données du prospect
  function saveProspectData(data: any) {
    console.log('Sauvegarde des données du prospect (simulée):', data);
    prospectData = data;
    successMessage = 'Données du prospect sauvegardées';
    setTimeout(() => { successMessage = ''; }, 3000);
  }
  
  // Charger les numéros de campagne (simulation)
  function loadCampaignNumbers() {
    console.log('Utilisation de numéros de campagne simulés');
    
    // Simuler les numéros de campagne
    campaignNumbers = [
      { phone_number: '0123456789', first_name: 'Jean', last_name: 'Dupont', lead_id: '101', called: false },
      { phone_number: '0234567890', first_name: 'Marie', last_name: 'Martin', lead_id: '102', called: false },
      { phone_number: '0345678901', first_name: 'Pierre', last_name: 'Durand', lead_id: '103', called: false },
      { phone_number: '0456789012', first_name: 'Sophie', last_name: 'Lefebvre', lead_id: '104', called: false }
    ];
    
    console.log(`${campaignNumbers.length} numéros simulés disponibles pour la campagne`);
  }
  
  // Charger les numéros de campagne au montage du composant
  onMount(() => {
    loadCampaignNumbers();
  });
  
  // Observer les changements dans la propriété callEnded
  $: if (callEnded) {
    handleEndCall();
  }
</script>

<div class="container-fluid p-0">
  <!-- Carte principale du composant de numérotation -->
  <div class="card mb-4 shadow-sm border-0 rounded-4 overflow-hidden">
  
    
    <div class="card-body p-4">
      <!-- Notifications avec animations -->
      {#if errorMessage}
        <div class="alert alert-danger d-flex align-items-center mb-3 border-0 shadow-sm" role="alert">
          <div class="alert-icon-container me-3 d-flex align-items-center justify-content-center">
            <i class="bi bi-exclamation-triangle-fill"></i>
          </div>
          <div class="flex-grow-1">{errorMessage}</div>
          <button type="button" class="btn-close" on:click={() => errorMessage = ''}></button>
        </div>
      {/if}
      
      {#if successMessage}
        <div class="alert alert-success d-flex align-items-center mb-3 border-0 shadow-sm" role="alert">
          <div class="alert-icon-container me-3 d-flex align-items-center justify-content-center">
            <i class="bi bi-check-circle-fill"></i>
          </div>
          <div class="flex-grow-1">{successMessage}</div>
          <button type="button" class="btn-close" on:click={() => successMessage = ''}></button>
        </div>
      {/if}
      
      <!-- Contrôles de numérotation améliorés -->
      <div class="dialer-controls mb-4">
        <div class="row g-3">
          <div class="col-md-6">
            <button 
              class="btn w-100 py-3 d-flex align-items-center justify-content-center {predictiveMode ? 'btn-danger' : 'btn-primary'} rounded-3 shadow-sm" 
              on:click={togglePredictiveMode}
            >
              <div class="btn-icon-container me-2 d-flex align-items-center justify-content-center">
                <i class="bi {predictiveMode ? 'bi-stop-circle-fill' : 'bi-play-circle-fill'}"></i>
              </div>
              <span class="fw-medium">{predictiveMode ? 'Arrêter le mode prédictif' : 'Démarrer le mode prédictif'}</span>
            </button>
          </div>
          
          <div class="col-md-6">
            <button 
              class="btn w-100 py-3 d-flex align-items-center justify-content-center btn-outline-secondary rounded-3" 
              disabled={$agentState.callActive} 
              on:click={checkForIncomingCalls}
            >
              <div class="btn-icon-container me-2 d-flex align-items-center justify-content-center">
                <i class="bi bi-arrow-repeat"></i>
              </div>
              <span class="fw-medium">Vérifier les appels</span>
            </button>
          </div>
        </div>
      </div>
  
      {#if $agentState.callActive}
        <!-- Carte d'appel actif avec design moderne -->
        <div class="active-call-card mb-4 rounded-4 shadow-sm border-0 p-0 position-relative overflow-hidden">
          <!-- Indicateur d'appel actif pulsant -->
          <div class="call-pulse-indicator"></div>
          
          <!-- En-tête d'appel avec dégradé -->
          <div class="active-call-header bg-gradient-success text-white p-3 d-flex align-items-center">
            <div class="call-icon-container rounded-circle bg-white bg-opacity-25 p-2 me-3 d-flex align-items-center justify-content-center">
              <i class="bi bi-telephone-fill text-white"></i>
            </div>
            <div class="flex-grow-1">
              <h5 class="mb-0 fw-semibold">Appel en cours</h5>
              <div class="small text-white text-opacity-75">
                <i class="bi bi-clock me-1"></i>
                <span>Durée: {Math.floor($callDuration / 60)}:{($callDuration % 60).toString().padStart(2, '0')}</span>
              </div>
            </div>
            <button 
              class="btn btn-sm btn-danger rounded-pill d-flex align-items-center shadow-sm" 
              on:click={handleEndCall}
            >
              <i class="bi bi-telephone-x-fill me-1"></i>
              <span>Terminer</span>
            </button>
          </div>
          
          <!-- Détails de l'appel -->
          <div class="active-call-details p-3">
            <div class="row g-3">
              <!-- Numéro de téléphone -->
              <div class="col-md-6">
                <div class="call-detail-card bg-light bg-opacity-50 rounded-3 p-3">
                  <div class="text-muted small mb-1">Numéro de téléphone</div>
                  <div class="d-flex align-items-center">
                    <div class="call-detail-icon me-2 bg-primary bg-opacity-10 text-primary rounded-circle p-1 d-flex align-items-center justify-content-center">
                      <i class="bi bi-telephone"></i>
                    </div>
                    <div class="fw-medium fs-5">{$agentState.phoneNumber || 'Non disponible'}</div>
                  </div>
                </div>
              </div>
              
              <!-- Nom du contact -->
              <div class="col-md-6">
                <div class="call-detail-card bg-light bg-opacity-50 rounded-3 p-3">
                  <div class="text-muted small mb-1">Nom du contact</div>
                  <div class="d-flex align-items-center">
                    <div class="call-detail-icon me-2 bg-primary bg-opacity-10 text-primary rounded-circle p-1 d-flex align-items-center justify-content-center">
                      <i class="bi bi-person"></i>
                    </div>
                    <div class="fw-medium fs-5">{$agentState.contactName || 'Non disponible'}</div>
                  </div>
                </div>
              </div>
              
              <!-- ID du prospect -->
              <div class="col-md-6">
                <div class="call-detail-card bg-light bg-opacity-50 rounded-3 p-3">
                  <div class="text-muted small mb-1">ID du prospect</div>
                  <div class="d-flex align-items-center">
                    <div class="call-detail-icon me-2 bg-primary bg-opacity-10 text-primary rounded-circle p-1 d-flex align-items-center justify-content-center">
                      <i class="bi bi-hash"></i>
                    </div>
                    <div class="fw-medium">{$agentState.leadId || 'Non disponible'}</div>
                  </div>
                </div>
              </div>
              
              <!-- Heure de début -->
              <div class="col-md-6">
                <div class="call-detail-card bg-light bg-opacity-50 rounded-3 p-3">
                  <div class="text-muted small mb-1">Heure de début</div>
                  <div class="d-flex align-items-center">
                    <div class="call-detail-icon me-2 bg-primary bg-opacity-10 text-primary rounded-circle p-1 d-flex align-items-center justify-content-center">
                      <i class="bi bi-clock-history"></i>
                    </div>
                    <div class="fw-medium">
                      {$agentState.callStartTime ? $agentState.callStartTime.toLocaleTimeString() : 'Non disponible'}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      {:else}
        <!-- Statut d'attente avec animation -->
        <div class="waiting-status-card rounded-4 shadow-sm border-0 p-4 mb-4 text-center">
          <div class="waiting-icon-container mb-3 mx-auto">
            <div class="waiting-icon-circle">
              <i class="bi bi-telephone-plus"></i>
            </div>
          </div>
          <h5 class="mb-2 fw-semibold">En attente d'appel</h5>
          <p class="text-muted mb-0">Le système vous attribuera automatiquement le prochain appel disponible.</p>
        </div>
      {/if}
  
      {#if predictiveMode}
        <!-- Mode prédictif actif avec animation -->
        <div class="predictive-mode-card rounded-4 shadow-sm border-0 p-4 mb-4 bg-gradient-warning bg-opacity-10">
          <div class="d-flex">
            <div class="predictive-icon-container me-3 d-flex align-items-center justify-content-center">
              <i class="bi bi-lightning-charge-fill"></i>
            </div>
            <div class="flex-grow-1">
              <h5 class="mb-2 fw-semibold text-warning">Mode prédictif actif</h5>
              <p class="mb-1">Le système compose automatiquement les numéros de la campagne.</p>
              
              {#if waitingForCall}
                <div class="d-flex align-items-center mt-2">
                  <div class="waiting-indicator me-2"></div>
                  <p class="fw-medium mb-0">En attente du prochain appel...</p>
                </div>
              {/if}
            </div>
          </div>
        </div>
      {/if}
    </div>
  </div>

  <!-- Carte des informations du prospect avec design moderne -->
  <div class="prospect-card mb-4 rounded-4 shadow-sm border-0 overflow-hidden">
    <div class="prospect-card-header bg-gradient-info p-3 d-flex align-items-center">
      <div class="prospect-icon-container rounded-circle bg-white bg-opacity-25 p-2 me-2 d-flex align-items-center justify-content-center">
        <i class="bi bi-person-vcard text-white"></i>
      </div>
      <h5 class="mb-0 text-white fw-semibold">Informations du prospect</h5>
    </div>
    
    <div class="prospect-card-body p-4">
      {#if $agentState.callActive}
        <!-- Afficher le formulaire avec animation d'entrée -->
        <div class="prospect-form-container">
          <ProspectForm prospectData={prospectData || {}} onSave={saveProspectData} />
        </div>
      {:else if prospectData}
        <!-- Afficher le formulaire avec les données existantes -->
        <div class="prospect-form-container">
          <ProspectForm prospectData={prospectData} onSave={saveProspectData} />
        </div>
      {:else}
        <!-- État vide avec illustration -->
        <div class="empty-prospect-state text-center py-4">
          <div class="empty-prospect-icon-container mx-auto mb-3">
            <i class="bi bi-person-badge"></i>
          </div>
          <h5 class="mb-2 fw-semibold">Aucun prospect actif</h5>
          <p class="text-muted mb-0">Les informations du prospect s'afficheront ici pendant un appel.</p>
        </div>
      {/if}
    </div>
  </div>
</div>

<style>
  /* Styles pour les dégradés */
  .bg-gradient-primary {
    background: linear-gradient(135deg, #4f46e5, #3b82f6);
  }
  
  .bg-gradient-success {
    background: linear-gradient(135deg, #10b981, #059669);
  }
  
  .bg-gradient-warning {
    background: linear-gradient(135deg, #f59e0b, #d97706);
  }
  
  .bg-gradient-info {
    background: linear-gradient(135deg, #0ea5e9, #0284c7);
  }
  
  /* Styles pour les indicateurs de statut */
  .status-indicator {
    width: 10px;
    height: 10px;
    border-radius: 50%;
  }
  
  .status-indicator.active {
    background-color: #10b981;
    box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.3);
    animation: pulse 2s infinite;
  }
  
  .status-indicator.ready {
    background-color: #10b981;
  }
  
  .status-indicator.waiting {
    background-color: #f59e0b;
  }
  
  /* Animation de pulsation pour l'indicateur d'appel actif */
  .call-pulse-indicator {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 4px;
    background: linear-gradient(90deg, transparent, #10b981, transparent);
    background-size: 200% 100%;
    animation: pulse-slide 2s infinite;
  }
  
  @keyframes pulse-slide {
    0% { background-position: 100% 0; }
    100% { background-position: -100% 0; }
  }
  
  @keyframes pulse {
    0% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.6); }
    70% { box-shadow: 0 0 0 6px rgba(16, 185, 129, 0); }
    100% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }
  }
  
  /* Styles pour les conteneurs d'icônes */
  .alert-icon-container {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background-color: rgba(255, 255, 255, 0.2);
  }
  
  .btn-icon-container {
    width: 24px;
    height: 24px;
  }
  
  .call-detail-icon {
    width: 32px;
    height: 32px;
  }
  
  .waiting-icon-container {
    width: 64px;
    height: 64px;
    position: relative;
  }
  
  .waiting-icon-circle {
    width: 100%;
    height: 100%;
    border-radius: 50%;
    background-color: rgba(14, 165, 233, 0.1);
    color: #0ea5e9;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    animation: pulse 2s infinite;
  }
  
  .predictive-icon-container {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background-color: rgba(245, 158, 11, 0.1);
    color: #f59e0b;
    font-size: 20px;
  }
  
  .empty-prospect-icon-container {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    background-color: rgba(107, 114, 128, 0.1);
    color: #6b7280;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 32px;
  }
  
  /* Indicateur d'attente */
  .waiting-indicator {
    width: 16px;
    height: 16px;
    border-radius: 50%;
    background-color: #f59e0b;
    position: relative;
  }
  
  .waiting-indicator:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    border-radius: 50%;
    background-color: rgba(245, 158, 11, 0.6);
    animation: pulse 2s infinite;
  }
  
  /* Styles pour les cartes */
  .active-call-card,
  .waiting-status-card,
  .predictive-mode-card,
  .prospect-card {
    transition: all 0.3s ease;
  }
  
  .active-call-card:hover,
  .waiting-status-card:hover,
  .predictive-mode-card:hover,
  .prospect-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05) !important;
  }
  
  /* Animation d'entrée pour le formulaire */
  .prospect-form-container {
    animation: fadeIn 0.5s ease-in-out;
  }
  
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
</style>
