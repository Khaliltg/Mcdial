<script lang="ts">
  import { onMount, onDestroy } from 'svelte';
  import { agentState, syncAgentStatus, pauseAgent, resumeAgent, endCall, startCall, updateAgentStatus } from '../stores/agent';
  import { agentStatus, setAgentPaused, setAgentReady, setAgentLogout, updateStatus, syncStateWithAgentStatus, syncAgentStatusWithState, setCallActive } from '../stores/agentStatus';
  import CallControls from './CallControls.svelte';
  import PredictiveDialer from './agent-interface/dialer/PredictiveDialer.svelte';
  import StatusButtons from './StatusButtons.svelte';
  import { api } from '../utils/fetchWithAuth';
  import { CHECK_CALLS_INTERVAL, STATUS_REFRESH_INTERVAL, AGENT_STATUSES } from '../utils/config';
  import { canMakeApiCall, recordApiCall } from '../utils/apiThrottle';
  import { get } from 'svelte/store';

  // Définition du type pour les codes de pause
  interface PauseCode {
    pause_code: string;
    pause_code_name: string;
    campaign_id?: string;
    billable?: string;
  }
  
  // Variables locales
  let isLoading = true;
  let error = '';
  let callCheckInterval: number;
  let statusRefreshInterval: number;
  let pauseReason = '';
  let selectedPauseCode = 'BREAK';
  let pauseCodes: PauseCode[] = [];
  let showPauseModal = false;
  let loadingPauseCodes = false;
  let pauseCodeError = '';
  
  // Variables réactives pour le statut actuel - utilisant le nouveau store agentStatus
  $: currentStatus = $agentStatus.status;
  $: isCallActive = $agentStatus.callActive;
  
  // Log pour déboguer les changements d'état
  $: console.log('Dashboard - État actuel du store agentStatus:', $agentStatus);
  
  // Variable pour limiter les synchronisations trop fréquentes
  let lastSyncTime = 0;
  const MIN_SYNC_INTERVAL = 2000; // 2 secondes minimum entre les syncs
  
  // Fonction pour synchroniser les stores sans déclencher d'appels API
  function syncStoresLocally() {
    const now = Date.now();
    if (now - lastSyncTime < MIN_SYNC_INTERVAL) {
      return; // Ignorer les synchronisations trop fréquentes
    }
    
    lastSyncTime = now;
    
    // Synchroniser uniquement si nécessaire
    if ($agentState.status !== $agentStatus.status) {
      console.log(`Synchronisation locale des stores: ${$agentState.status}`);
      updateStatus($agentState.status, $agentState.pauseCode, $agentState.pauseReason);
    }
  }
  
  // Surveiller les changements d'agentState pour synchroniser localement
  $: {
    if ($agentState) {
      syncStoresLocally();
    }
  }

  // Fonction pour charger les informations de l'agent
  async function loadAgentInfo() {
    try {
      const response = await api.get('/agent/info');
      
      if (response.ok) {
        const data = await response.json();
        console.log('Informations agent chargées:', data);
        
        // Mettre à jour le statut de l'agent avec la fonction dédiée
        if (data.status) {
          // Utiliser updateAgentStatus pour mettre à jour le statut
          updateAgentStatus(data.status, data.pauseCode, data.pauseReason);
        }
        
        // Mettre à jour les autres informations de l'agent
        agentState.update(state => ({
          ...state,
          user: data.user || state.user,
          fullName: data.full_name || state.fullName,
          phoneLogin: data.phone_login || state.phoneLogin,
          campaignId: data.campaign_id || state.campaignId,
          campaignName: data.campaign_name || state.campaignName,
          extension: data.extension || state.extension,
        }));
      } else {
        console.error('Erreur lors du chargement des informations de l\'agent:', response.status);
        error = 'Impossible de charger les informations de l\'agent';
      }
    } catch (err) {
      console.error('Erreur lors du chargement des informations de l\'agent:', err);
      error = 'Erreur de connexion au serveur';
    } finally {
      isLoading = false;
    }
  }

  // Fonction pour vérifier les appels actifs
  async function checkCalls() {
    try {
      const response = await api.get('/agent/calls/check-calls');
      
      if (response.ok) {
        const data = await response.json();
        
        // Si un appel entrant ou sortant est actif, mettre à jour l'état
        const activeCall = data.incomingCalls || data.outgoingCalls;
        const currentState = get(agentState);
        
        if (activeCall && !currentState.callActive) {
          console.log('Appel actif détecté, mise à jour du statut');
          
          // Utiliser la fonction dédiée startCall pour mettre à jour l'état
          // Cela garantit que tous les composants sont notifiés du changement
          startCall({
            callId: activeCall.uniqueid,
            leadId: activeCall.lead_id,
            phoneNumber: activeCall.phone_number,
            contactName: activeCall.contact_name || 'Inconnu',
            direction: activeCall.direction || 'outbound'
          });
        }
      }
    } catch (err) {
      console.error('Erreur lors de la vérification des appels:', err);
    }
  }

  // Fonction pour rafraîchir le statut de l'agent
  // Fonction pour rafraîchir le statut avec limitation de débit
  async function refreshStatus() {
    // Vérifier si on peut faire un appel API
    if (!canMakeApiCall()) {
      console.log('Rafraîchissement du statut ignoré - Trop fréquent');
      return;
    }
    
    try {
      console.log('Appel API: /agent/info');
      const response = await api.get('/agent/info');
      
      if (response.ok) {
        const data = await response.json();
        const currentStatus = get(agentStatus);
        
        // Mettre à jour l'état de l'agent avec les données du serveur
        if (data.status) {
          // Vérifier si le statut a changé
          if (data.status !== currentStatus.status) {
            console.log(`Mise à jour du statut: ${currentStatus.status} -> ${data.status}`);
            
            // Mettre à jour uniquement le store agentStatus
            // Le store agentState sera mis à jour par syncAgentStatus si nécessaire
            updateStatus(data.status, data.pauseCode, data.pauseReason);
          }
          
          console.log(`Statut après synchronisation: ${data.status}`);
        }
      }
    } catch (err) {
      console.error('Erreur lors du rafraîchissement du statut:', err);
    }
  }
  
  // Fonction pour mettre l'agent en pause
  // Fonction pour récupérer les codes de pause disponibles
  async function loadPauseCodes() {
    loadingPauseCodes = true;
    pauseCodeError = '';
    
    try {
      const response = await api.get('/agent/pause-codes');
      
      if (response.ok) {
        const data = await response.json();
        pauseCodes = data;
        
        // Sélectionner le premier code de pause par défaut s'il y en a
        if (pauseCodes.length > 0 && !selectedPauseCode) {
          selectedPauseCode = pauseCodes[0].pause_code;
        }
        
        console.log('Codes de pause chargés:', pauseCodes);
      } else {
        console.error('Erreur lors du chargement des codes de pause:', response.status);
        pauseCodeError = 'Impossible de charger les codes de pause';
        pauseCodes = [{ pause_code: 'BREAK', pause_code_name: 'Pause standard' }];
      }
    } catch (err) {
      console.error('Erreur lors du chargement des codes de pause:', err);
      pauseCodeError = 'Erreur de connexion';
      pauseCodes = [{ pause_code: 'BREAK', pause_code_name: 'Pause standard' }];
    } finally {
      loadingPauseCodes = false;
    }
  }
  
  // Fonction pour ouvrir le modal de pause
  function openPauseModal() {
    // Réinitialiser les valeurs
    pauseReason = '';
    selectedPauseCode = 'BREAK';
    
    // Charger les codes de pause
    loadPauseCodes();
    
    // Afficher le modal
    showPauseModal = true;
  }

  async function handlePauseAgent() {
    try {
      console.log('Tentative de mise en pause de l\'agent');
      
      // Utiliser le code de pause sélectionné par l'utilisateur
      const pauseCode = selectedPauseCode;
      const reason = pauseReason || 'Pause';
      
      console.log(`Mise en pause avec code: ${pauseCode}, raison: ${reason}`);
      
      // Mettre à jour les deux stores AVANT l'appel API pour une UI réactive
      pauseAgent(pauseCode, reason);
      setAgentPaused(pauseCode, reason);
      
      // Synchroniser immédiatement les deux stores pour une mise à jour instantanée de l'interface
      syncStateWithAgentStatus();
      syncAgentStatusWithState();
      
      // Fermer le modal et réinitialiser les valeurs immédiatement pour une UI réactive
      showPauseModal = false;
      pauseReason = '';
      selectedPauseCode = 'BREAK';
      
      // Vérifier si on peut faire un appel API
      if (!canMakeApiCall()) {
        console.log('Mise à jour du statut côté serveur reportée - Trop d\'appels récents');
        return;
      }
      
      // Appel API pour mettre à jour le statut côté serveur
      console.log('Envoi du statut PAUSED au serveur');
      const response = await api.post('/agent/status', {
        status: AGENT_STATUSES.PAUSED,
        pauseCode,
        pauseReason: reason
      });
      
      if (!response.ok) {
        console.error('Erreur lors de la mise en pause côté serveur:', response.status);
        // En cas d'erreur, on pourrait revenir à l'état précédent ou afficher un message d'erreur
      }
    } catch (err) {
      console.error('Erreur lors de la mise en pause:', err);
      // Afficher un message d'erreur à l'utilisateur
    }
  }
  
  // Fonction pour reprendre l'activité après une pause
  async function handleResumeAgent() {
    try {
      console.log('Reprise de l\'activité après pause');
      
      // Mettre à jour les deux stores
      resumeAgent();
      setAgentReady();
      
      // Synchroniser immédiatement les deux stores pour une mise à jour instantanée de l'interface
      syncStateWithAgentStatus();
      syncAgentStatusWithState();
      
      // Vérifier si on peut faire un appel API
      if (!canMakeApiCall()) {
        console.log('Mise à jour du statut côté serveur reportée - Trop d\'appels récents');
        return;
      }
      
      // Appel API
      console.log('Envoi du statut READY au serveur');
      const response = await api.post('/agent/status', {
        status: AGENT_STATUSES.READY
      });
      
      if (!response.ok) {
        console.error('Erreur lors de la reprise d\'activité côté serveur:', response.status);
      }
    } catch (err) {
      console.error('Erreur lors de la reprise d\'activité:', err);
    }
  }

  // Variables pour les contrôles d'appel
  let isMuted = false;
  let isOnHold = false;
  let isRecording = false;

  // Gérer la mise en sourdine
  async function handleMute() {
    try {
      const response = await api.post('/agent/calls/mute', { mute: !isMuted });
      if (response.ok) {
        isMuted = !isMuted;
      }
    } catch (err) {
      console.error('Erreur lors de la mise en sourdine:', err);
    }
  }

  // Gérer la mise en attente
  async function handleHold() {
    try {
      const response = await api.post('/agent/calls/hold', { hold: !isOnHold });
      if (response.ok) {
        isOnHold = !isOnHold;
      }
    } catch (err) {
      console.error('Erreur lors de la mise en attente:', err);
    }
  }

  // Gérer l'enregistrement
  async function handleRecording() {
    try {
      const response = await api.post('/agent/calls/record', { record: !isRecording });
      if (response.ok) {
        isRecording = !isRecording;
      }
    } catch (err) {
      console.error('Erreur lors de l\'enregistrement:', err);
    }
  }

  // Gérer la fin d'un appel
  async function handleCallEnded() {
    console.log('Appel terminé, réinitialisation de l\'interface');
    
    try {
      const response = await api.post('/agent/calls/hangup', {});
      
      // Réinitialiser les états des contrôles
      isMuted = false;
      isOnHold = false;
      isRecording = false;
      
      // Attendre un court délai avant de réinitialiser l'état
      setTimeout(() => {
        endCall();
      }, 1000);
    } catch (err) {
      console.error('Erreur lors de la fin de l\'appel:', err);
    }
  }

  // Variable pour éviter les appels API trop fréquents
  // Nous utilisons maintenant l'utilitaire apiThrottle pour la limitation des appels API
  // Les variables lastApiCallTime et MIN_API_CALL_INTERVAL sont définies dans apiThrottle.ts
  
  // Nous n'utilisons plus de synchronisation forcée par intervalle
  // Le statut est maintenant géré de manière réactive via le store Svelte
  
  // Version modifiée de checkCalls avec limitation de débit
  async function throttledCheckCalls() {
    if (!canMakeApiCall()) return;
    
    await checkCalls();
  }
  
  onMount(async () => {
    // Charger les informations de l'agent au démarrage
    await loadAgentInfo();
    
    // Configurer l'intervalle de vérification des appels
    callCheckInterval = window.setInterval(throttledCheckCalls, CHECK_CALLS_INTERVAL);
    
    // Nous n'utilisons plus d'intervalle de synchronisation du statut
    
    // Vérifier les appels immédiatement
    throttledCheckCalls();
    
    console.log('Intervalles de synchronisation configurés');
  });

  onDestroy(() => {
    // Nettoyer les intervalles lors de la destruction du composant
    if (callCheckInterval) clearInterval(callCheckInterval);
    // Nous n'avons plus d'intervalle de synchronisation à nettoyer
  });
</script>

<div class="dashboard-container">
  <!-- Contenu principal -->
  <div class="container py-4">
    {#if isLoading}
      <div class="d-flex justify-content-center my-5">
        <div class="spinner-border text-primary" role="status">
          <span class="visually-hidden">Chargement...</span>
        </div>
      </div>
    {:else if error}
      <div class="alert alert-danger" role="alert">
        {error}
        <button class="btn btn-outline-danger ms-3" on:click={loadAgentInfo}>Réessayer</button>
      </div>
    {:else}
      <div class="row justify-content-center">
        <!-- Colonne de gauche - PredictiveDialer -->
        <div class="col-md-5">
          <PredictiveDialer callEnded={false} />
        </div>
        
        <!-- Colonne de droite - Statistiques et Contrôles -->
        <div class="col-md-5">
          <!-- Statistiques de l'agent -->
          <div class="card mb-4">
            
            <div class="card-body pt-0">
              <!-- Boutons de statut avec design compact -->
              <div class="agent-status-controls mb-4 mt-3">
                <h6 class="text-muted mb-2">Statut de l'agent</h6>
                
                <!-- Nouveau composant StatusButtons -->
                <StatusButtons onPauseClick={openPauseModal} />
                
                <!-- Statut actuel (texte simple) -->
                <div class="current-status-text text-center mt-2">
                  <small class="text-muted">
                    {currentStatus === AGENT_STATUSES.READY ? 'Prêt' : 
                     currentStatus === AGENT_STATUSES.PAUSED ? 'En pause' + ($agentState.pauseReason ? ` (${$agentState.pauseReason})` : '') : 
                     currentStatus === AGENT_STATUSES.INCALL ? 'En appel' : 
                     currentStatus === AGENT_STATUSES.LOGOUT ? 'Déconnecté' : 'Hors ligne'}
                  </small>
                </div>
              </div>
            </div>
         
          </div>
          
    
        </div>
      </div>
    {/if}
  </div>
</div>

<style>
  .dashboard-container {
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    background-color: #f8f9fa;
  }
  
  @keyframes pulse {
    0% {
      box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.4);
    }
    70% {
      box-shadow: 0 0 0 10px rgba(16, 185, 129, 0);
    }
    100% {
      box-shadow: 0 0 0 0 rgba(16, 185, 129, 0);
    }
  }
  
  /* Styles pour l'animation de pulsation */
</style>

<!-- Modal de pause -->
{#if showPauseModal}
<div class="modal fade show" style="display: block; background-color: rgba(0,0,0,0.5);" tabindex="-1" aria-modal="true" role="dialog">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Mettre en pause</h5>
        <button type="button" class="btn-close" aria-label="Close" on:click={() => showPauseModal = false}></button>
      </div>
      <div class="modal-body">
        <!-- Sélection du code de pause -->
        <div class="mb-3">
          <label for="pauseCode" class="form-label">Code de pause</label>
          {#if loadingPauseCodes}
            <div class="d-flex align-items-center mb-2">
              <div class="spinner-border spinner-border-sm text-primary me-2" role="status">
                <span class="visually-hidden">Chargement...</span>
              </div>
              <span class="text-muted">Chargement des codes de pause...</span>
            </div>
          {/if}
          
          {#if pauseCodeError}
            <div class="alert alert-warning py-2">{pauseCodeError}</div>
          {/if}
          
          <select class="form-select" id="pauseCode" bind:value={selectedPauseCode}>
            {#each pauseCodes as code}
              <option value={code.pause_code}>{code.pause_code_name}</option>
            {/each}
          </select>
          
          <div class="d-flex justify-content-end mt-2">
            <button type="button" class="btn btn-sm btn-outline-secondary" on:click={loadPauseCodes} disabled={loadingPauseCodes}>
              <i class="bi bi-arrow-clockwise me-1"></i> Actualiser
            </button>
          </div>
        </div>
        
        <!-- Raison de la pause -->
        <div class="mb-3">
          <label for="pauseReason" class="form-label">Raison de la pause</label>
          <input type="text" class="form-control" id="pauseReason" bind:value={pauseReason} placeholder="Saisir la raison de la pause...">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" on:click={() => showPauseModal = false}>Annuler</button>
        <button type="button" class="btn btn-primary" on:click={handlePauseAgent}>
          <i class="bi bi-pause-circle me-1"></i> Confirmer la pause
        </button>
      </div>
    </div>
  </div>
</div>
{/if}
