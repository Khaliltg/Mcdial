import { writable, get } from 'svelte/store';
import { AGENT_STATUSES, agentState } from './agent';

// Type pour le statut de l'agent
export type AgentStatusType = string;

// Interface pour les informations de statut
export interface AgentStatusInfo {
  status: AgentStatusType;
  statusSince: Date;
  pauseCode?: string;
  pauseReason?: string;
  callActive: boolean;
}

// État initial du statut
const initialStatus: AgentStatusInfo = {
  status: AGENT_STATUSES.OFFLINE as AgentStatusType,
  statusSince: new Date(),
  pauseCode: undefined,
  pauseReason: undefined,
  callActive: false
};

// Création du store writable pour le statut de l'agent
export const agentStatus = writable<AgentStatusInfo>(initialStatus);

// Fonction pour mettre à jour le statut
export function updateStatus(status: AgentStatusType, pauseCode?: string, pauseReason?: string): void {
  agentStatus.update(currentStatus => {
    // Ne mettre à jour que si le statut a réellement changé
    if (status === currentStatus.status && 
        pauseCode === currentStatus.pauseCode && 
        pauseReason === currentStatus.pauseReason) {
      return currentStatus; // Aucun changement nécessaire
    }
    
    console.log(`[agentStatus] Mise à jour du statut: ${currentStatus.status} -> ${status}`);
    
    return {
      ...currentStatus,
      status,
      statusSince: new Date(),
      pauseCode,
      pauseReason
    };
  });
}

// Fonction pour mettre l'agent en pause
export function setAgentPaused(pauseCode: string, pauseReason: string): void {
  updateStatus(AGENT_STATUSES.PAUSED as AgentStatusType, pauseCode, pauseReason);
}

// Fonction pour mettre l'agent en statut prêt
export function setAgentReady(): void {
  updateStatus(AGENT_STATUSES.READY as AgentStatusType);
}

// Fonction pour mettre l'agent en statut déconnecté
export function setAgentLogout(): void {
  updateStatus(AGENT_STATUSES.LOGOUT as AgentStatusType);
}

// Fonction pour mettre à jour le statut d'appel
export function setCallActive(isActive: boolean): void {
  agentStatus.update(currentStatus => {
    if (currentStatus.callActive === isActive) {
      return currentStatus; // Aucun changement nécessaire
    }
    
    console.log(`[agentStatus] Mise à jour du statut d'appel: ${currentStatus.callActive} -> ${isActive}`);
    
    // Si un appel devient actif, mettre le statut à INCALL
    // Si un appel se termine, remettre le statut à READY
    const newStatus = isActive ? AGENT_STATUSES.INCALL : AGENT_STATUSES.READY;
    
    return {
      ...currentStatus,
      status: newStatus as AgentStatusType,
      statusSince: new Date(),
      callActive: isActive
    };
  });
}

// Fonction pour synchroniser le store agentStatus avec agentState
export function syncAgentStatusWithState(): void {
  const currentState = get(agentState);
  
  agentStatus.update(current => ({
    ...current,
    status: currentState.status as AgentStatusType,
    pauseCode: currentState.pauseCode,
    pauseReason: currentState.pauseReason,
    callActive: currentState.callActive,
    statusSince: new Date()
  }));
  
  console.log('[agentStatus] Synchronisé avec agentState:', currentState.status);
}

// Fonction pour synchroniser le store agentState avec agentStatus
export function syncStateWithAgentStatus(): void {
  const currentStatus = get(agentStatus);
  
  agentState.update(current => ({
    ...current,
    status: currentStatus.status,
    pauseCode: currentStatus.pauseCode,
    pauseReason: currentStatus.pauseReason,
    callActive: currentStatus.callActive
  }));
  
  console.log('[agentStatus] agentState synchronisé avec agentStatus:', currentStatus.status);
}
