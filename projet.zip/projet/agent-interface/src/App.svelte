<script lang="ts">
  import { onMount } from 'svelte';
  import Login from './components/Login.svelte';
  import Dashboard from './components/Dashboard.svelte';
  import StatusBar from './components/StatusBar.svelte';
  import CallControls from './components/CallControls.svelte';
  import { agentState, updateAgentInfo } from './stores/agent';
  import { checkAuth } from './utils/fetchWithAuth';
  
  let loading = true;
  
  onMount(async () => {
    try {
      const authResult = await checkAuth();
      if (authResult.authenticated) {
        // Mettre à jour les informations de l'agent
        updateAgentInfo({
          user: authResult.user.user,
          fullName: authResult.user.full_name,
          phoneLogin: authResult.user.phone_login || "",
          extension: authResult.user.extension,
          campaignId: authResult.user.campaign_id || "",
          campaignName: authResult.user.campaign_name || "Aucune campagne",
          status: "READY",
          statusSince: new Date()
        });
      }
    } catch (error) {
      console.error("Erreur lors de la vérification de l'authentification:", error);
    } finally {
      loading = false;
    }
  });
</script>

{#if loading}
  <div class="loading-container">
    <div class="spinner-border text-primary" role="status">
      <span class="visually-hidden">Chargement...</span>
    </div>
    <p class="mt-3">Chargement de l'interface agent...</p>
  </div>
{:else if $agentState.isAuthenticated}
  <div class="agent-interface">
    <StatusBar />
    <div class="container-fluid mt-3">
      <Dashboard />
    </div>
  </div>
{:else}
  <Login />
{/if}

<style>
  .loading-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
    width: 100%;
  }
  
  .agent-interface {
    display: flex;
    flex-direction: column;
    height: 100vh;
  }
</style>
